# Binding global constraints

- Desktop resident view contains only rope, clips and paper. Put language and appearance controls at the top right of the first-level Composer, Detail and Calendar, before close, in a consistent visible position. Never put controls above the rope or hide the only entry in Settings/More.
- Two restrained sliding capsules: fixed `中 / EN` language labels, thin SVG sun/moon appearance symbols; no flags or large backing toolbar. Concept sizes: language about 88×30 DIP, appearance about 72×30 DIP, total about 168 DIP, desktop hit height about 36 DIP. At widths 350/380/480/740, shorten the title before hiding either control or close; no horizontal overflow. Every icon has complete tooltip and accessible name.
- First new profile: Chinese OS languages select `zh-CN`, other languages select `en`; an existing profile with no preference stays Chinese. Appearance starts following OS; manual sun/moon selection overrides it, secondary Settings offers Follow system again. Persist in a separate profile-level preference file to avoid incrementing note snapshot revisions or conflicting with live autosave. Keep schema3 note structure/IDs/dates unchanged and do not overwrite hotkeys, storage paths or other settings.
- Translate app labels, hints, errors, empty states, hover/focus tooltips, tray/context menus, settings, destructive confirmations and calendar formats/plurals. Use centrally maintained typed keys and placeholders. Never translate/rewrite user note title/body/project/custom Agent names. Localize system General/Ungrouped by system IDs. Locale/theme updates do not remount views, steal editor focus, lose selection/scroll/IME candidates or overwrite dirty content.
- Light: warm paper and ink teal. Dark: deep blue gray surfaces, dim warm gray paper and warm pale text, with small coral accents. Main paper, all auxiliary views, settings, popovers/tooltips/menus follow the effective theme. Text contrast at least 4.5:1; retain visible focus/selected states in high contrast/forced colors. Reuse approved logo/clip assets unchanged. Existing vibrancy/acrylic fallback is not native Liquid Glass. Never change OS settings.
- Smooth short tactile slide: slight press compression, continuous pointer-following thumb, gentle settling on release, click animates too. Aim about 140–180 ms; any measured adjustment is recorded. Reverse from the current visual position immediately. No infinite/long motion or blocked input; correctness never waits for animation end. Click/drag/keyboard arrows/Home/End work; threshold about 12 DIP; Escape/pointercancel restores committed choice. Reduced motion and forced colors suppress decorative movement, preserving all operations. All switch hit regions are no-drag.
- Validate preference payloads and sender ownership, serialize/sequence concurrent writes and refuse stale callbacks. Failed persistence visibly retains/reverts to the last durable preference while protecting edit content. Corrupt/unreadable preference files must be preserved and surfaced, not silently overwritten. First-profile detection must precede creation of a new snapshot and must not read user note contents merely to decide language.
- Mac and Windows are verified separately. Controlled DOM/source/CI checks do not prove physical IME, DPI, multi-display, focus, natural motion or WeChat/Doubao/WorkBuddy reception. Never send to real conversations, silently copy/paste, request extra OS permissions, modify the user's installation or make the repository public.
- Use isolated synthetic profiles. Protect existing Electron PID30628, real data, original `out`/dependencies and other worktrees. Prefer a separate temporary build output for tests. Restore injected faults and held replies, finish composition/save/flush, close and quit normally, then remove only owned temporary processes/directories. Retain failed logs, exact source inputs and necessary screenshots; no assertion weakening.
- User/repository authorize validated stages on main, push and new private preview packages. No force/reset/history rewrite/G7 integration. Use new `0.0.17-preview.3` for this increment; never reuse .2/.16 tags or replace installed apps. Run Node24.19.0 from bundled runtime, explicit valid workdir and `/bin/sh` login false.


# ONE combined final fix wave

BASE88c6e5a0476bcec647525dd02ec08792e3d40611. Read full final-review.md findings and declined-item bounds. The following issues are verbatim:

## Issues

### Critical — 0

None found.

### Important — 1

**I1 — A preceding successful write hides the newest preference write failure.**

- **Location:** `src/renderer/components/PreferencesControl.tsx:31` (related version reset at lines 28-29; ordered repository writes at `src/main/store/preferences.ts:28-37`).
- **Trigger:** With durable preference version 0, choose English and then Dark before the first write completes. Both requests capture `base=0`. The English write succeeds and broadcasts version 1; the component renders it. The queued Dark write then fails, for example because disk space or permissions change. Dark is still the newest intent/request, but `version.current===base` is false, so its error is discarded.
- **Evidence:** A focused Node24.19.0 in-memory probe executed the exact `change` function extracted from line 31 (only its TypeScript parameter annotation removed), with deferred bridge promises and the actual version-ref update order. Output was `{"node":"v24.19.0","sourceLine":31,"requests":[{"patch":{"locale":"en"},"seq":1},{"patch":{"theme":"dark"},"seq":2}],"durableVersion":1,"latestFailed":true,"error":"","expectedError":"ENOSPC","failureSilentlySuppressed":true}`. Main publishes each successful queued write; it does not publish a failure or set `preferences.error` for update failures, so there is no other alert path. This is a controlled callback-order probe, not an Electron/physical reproduction.
- **Impact:** The user receives no explanation that their newest choice was not saved. The durable value remains protected, but the explicit failed-persistence visibility contract is violated during ordinary rapid switching/slow IO. Existing appearance-workflow tests hold an **older failure then make a newer success**; they do not cover **older success then newest failure**.
- **Fix:** Track intent/operation ordering separately from the durable version and suppress only a failure actually superseded by a later intent/success. Do not treat every version advance as proof that the latest request is stale. Preserve cross-control/cross-window stale-error rejection. Add a focused deferred-write regression with both requests issued before the first success, first success broadcast rendered, and latest IO failure delivered; require a current-locale alert, latest durable selection and unchanged note content. Also cover the rejection/catch variant.

### Minor — 2

**M1 — Rejected worker receipts are labeled completed.**

- **Location:** `tests/electron/packaged-launch.cjs:63-66`.
- **Trigger/evidence:** A parsed worker receipt has the wrong profile or executable. The ownership check rejects it and leaves `passed=false` with `Worker receipt does not match this owned invocation`, but `completed` remains truthy and the final stage becomes `worker-completed`.
- **Impact:** This does not turn a failed check into a pass, invalidate actual matching package receipts, or justify a release block by itself. It can mislead stage-based diagnostics into believing this invocation produced an accepted completion receipt.
- **Fix:** Derive the stage from receipt acceptance, with an explicit mismatched/rejected-receipt stage. Add a small mismatch case when maintaining this harness.

**M2 — Windows verify retains an unresolved shell-argument deprecation.**

- **Location:** `acceptance/evidence/appearance/task2-rebuild-d9cf75b/windows-run-37963724007-full.log:279`.
- **Trigger/evidence:** The successful Windows `npm run verify` emitted Node DEP0190 for arguments passed with `shell:true`. The exact caller is not identified by the retained log; this review does not attribute it to a guessed source line.
- **Impact:** Nonblocking maintenance/diagnostic debt. The warning alone does not establish exploitable input or failed package behavior, and the run's actual success remains valid.
- **Fix:** Trace the emitting caller in a future appropriate Windows harness run and use direct executable invocation or deliberate shell-safe construction as applicable. Preserve the original log and do not suppress the warning merely to obtain clean output.


# Controller scope ruling and required proof

Fix I1 and M1 in this ONE combined source/test wave. Keep M2 as explicitly deferred diagnostic maintenance: caller unproven, current logs retained, no warning suppression or speculative source mutation. Use focused RED/GREEN for newest request IO-result failure AND rejected/catch response after older successful write/broadcast; current-locale visible alert, latest durable selection and unchanged note bytes/focus. Existing older failure after newer success and cross-control/cross-window stale-error protections must stay correct. Determine ordering from actual implementation rather than simply removing a guard without honoring those cases. M1 needs a concrete mismatched worker receipt regression and accepted-receipt path unchanged.

No suite/CI/package build until minimal amended-covering tests pass. Then run appropriate current typecheck/full unit once and serial actualsource Electron appearance workflows needed for amended renderer interactions; all original3 actual-package assertions remain unchanged and will run against freshly rebuilt packages later. Root/Task2 will rebuild BOTH afterward on new exact reviewed freeze, private draft currently d9cf source is OLDcandidate. Preserve originalfinalreview/d9cfsource/input/binary receipts andfailedruns. No remote/tag/draft/publish/README, no externaldocs/.planning updates byyou. Newstagecommit onmain source+own evidence only; noforce/reset.

Use own isolatedbuild/output/profile, sameprotected30628/originalout/deps/12worktrees. Restorefaults/heldreplies, finalcomposition/saveflush, normalclose/quit thenexactownedPID/profilecleanup, retainallfailures. Completeper-run source capture exact keyset/raw/canonical; do not relabel current3cb/d9cfpackaged regression as new-source package. Anyfailure that prevents normalcleanup mustbe reported withreceipt, no broadkill. No subagents.

Report .superpowers/sdd/LOCALE-APPEARANCE-PLAN/final-fix-report.md: actual amendedfiles/commit(s), before/after behavior, exacttests/commands/counts andredfailures, source vector before/after/per-runcomplete, allownedcleanup/protectedfacts andremaining scope. Full evidence tracked acceptance/evidence/appearance/final-fix/. Do NOTpush untilroot handoff; sharedindexsolewriter duringyourfix, rootnoGitcommit. Concise return source/evidenceSHA, test/counts, concerns. Scopedreview follows beforebothbuilds.
