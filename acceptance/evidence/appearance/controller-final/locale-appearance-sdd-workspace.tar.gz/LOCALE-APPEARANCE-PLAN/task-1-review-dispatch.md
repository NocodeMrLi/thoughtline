# Task Reviewer Prompt Template

Use this template when dispatching a task reviewer subagent. The reviewer
reads the task's diff once and returns two verdicts: spec compliance and
code quality.

**Purpose:** Verify one task's implementation matches its requirements (nothing
more, nothing less) and is well-built (clean, tested, maintainable)

```
Subagent (general-purpose):
  description: "Review Task N (spec + quality)"
  model: [MODEL — REQUIRED: choose per SKILL.md Model Selection; an omitted
         model silently inherits the session's most expensive one]
  prompt: |
    You are reviewing one task's implementation: first whether it matches its
    requirements, then whether it is well-built. This is a task-scoped gate,
    not a merge review — a broad whole-branch review happens separately after
    all tasks are complete.

    ## What Was Requested

    Read the task brief: /Users/lihongwei/Desktop/晾念头 : Thoughtline/app/.superpowers/sdd/LOCALE-APPEARANCE-PLAN/task-1-brief.md

    Global constraints from the spec/design that bind this task:
    # Binding global constraints

- Desktop resident view contains only rope, clips and paper. Put language and appearance controls at the top right of the first-level Composer, Detail and Calendar, before close, in a consistent visible position. Never put controls above the rope or hide the only entry in Settings/More.
- Two restrained sliding capsules: fixed `中 / EN` language labels, thin SVG sun/moon appearance symbols; no flags or large backing toolbar. Concept sizes: language about 88×30 DIP, appearance about 72×30 DIP, total about 168 DIP, desktop hit height about 36 DIP. At widths 350/380/480/740, shorten the title before hiding either control or close; no horizontal overflow. Every icon has complete tooltip and accessible name.
- First new profile: Chinese OS languages select `zh-CN`, other languages select `en`; an existing profile with no preference stays Chinese. Appearance starts following OS; manual sun/moon selection overrides it, secondary Settings offers Follow system again. Persist in a separate profile-level preference file to avoid incrementing note snapshot revisions or conflicting with live autosave. Keep schema3 note structure/IDs/dates unchanged and do not overwrite hotkeys, storage paths or other settings.
- Translate app labels, hints, errors, empty states, hover/focus tooltips, tray/context menus, settings, destructive confirmations and calendar formats/plurals. Use centrally maintained typed keys and placeholders. Never translate/rewrite user note title/body/project/custom Agent names. Localize system General/Ungrouped by system IDs. Locale/theme updates do not remount views, steal editor focus, lose selection/scroll/IME candidates or overwrite dirty content.
- Light: warm paper and ink teal. Dark: deep blue gray surfaces, dim warm gray paper and warm pale text, with small coral accents. Main paper, all auxiliary views, settings, popovers/tooltips/menus follow the effective theme. Text contrast at least 4.5:1; retain visible focus/selected states in high contrast/forced colors. Reuse approved logo/clip assets unchanged. Existing vibrancy/acrylic fallback is not native Liquid Glass. Never change OS settings.
- Smooth short tactile slide: slight press compression, continuous pointer-following thumb, gentle settling on release, click animates too. Aim about 140–180 ms; any measured adjustment is recorded. Reverse from the current visual position immediately. No infinite/long motion or blocked input; correctness never waits for animation end. Click/drag/keyboard arrows/Home/End work; threshold about 12 DIP; Escape/pointercancel restores committed choice. Reduced motion and forced colors suppress decorative movement, preserving all operations. All switch hit regions are no-drag.
- Validate preference payloads and sender ownership, serialize/sequence concurrent writes and refuse stale callbacks. Failed persistence visibly retains/reverts to the last durable preference while protecting edit content. Corrupt/unreadable preference files must be preserved and surfaced, not silently overwritten. First-profile detection must precede creation of a new snapshot and must not read user note contents merely to decide language.
- Mac and Windows are verified separately. Controlled DOM/source/CI checks do not prove physical IME, DPI, multi-display, focus, natural motion or WeChat/Doubao/WorkBuddy reception. Never send to real conversations, silently copy/paste, request extra OS permissions, modify the user's installation or make the repository public.
- Use isolated synthetic profiles. Protect existing Electron PID30628, real data, original `out`/dependencies and other worktrees. Prefer a separate temporary build output for tests. Restore injected faults and held replies, finish composition/save/flush, close and quit normally, then remove only owned temporary processes/directories. Retain failed logs, exact source inputs and necessary screenshots; no assertion weakening.
- User/repository authorize validated stages on main, push and new private preview packages. No force/reset/history rewrite/G7 integration. Use new `0.0.17-preview.3` for this increment; never reuse .2/.16 tags or replace installed apps. Run Node24.19.0 from bundled runtime, explicit valid workdir and `/bin/sh` login false.



    ## What the Implementer Claims They Built

    Read the implementer's report: /Users/lihongwei/Desktop/晾念头 : Thoughtline/app/.superpowers/sdd/LOCALE-APPEARANCE-PLAN/task-1-report.md

    ## Diff Under Review

    **Base:** 713a1fe30482930b24a23b40f2d75ac495057a40
    **Head:** d489b1deed3992fd577da87d390dbc6bddabed3b
    **Diff file:** /Users/lihongwei/Desktop/晾念头 : Thoughtline/app/.superpowers/sdd/LOCALE-APPEARANCE-PLAN/task-1-production.diff

    Read the diff file once — it contains the commit list, a stat summary,
    and the full diff with surrounding context, and it is your view of the
    change. The diff's context lines ARE the changed files: do not Read a
    changed file separately unless a hunk you must judge is cut off
    mid-function — and say so in your report. Do not re-run git commands.
    If the diff file is missing, fetch the diff yourself:
    `git diff --stat 713a1fe30482930b24a23b40f2d75ac495057a40..d489b1deed3992fd577da87d390dbc6bddabed3b` and `git diff 713a1fe30482930b24a23b40f2d75ac495057a40..d489b1deed3992fd577da87d390dbc6bddabed3b`.
    Do not crawl the broader codebase. Inspect code outside the diff only
    to evaluate a concrete risk you can name — one focused check per named
    risk, and name both the risk and what you checked in your report.
    Cross-cutting changes are legitimate named risks: if the diff changes
    lock ordering, a function or API contract, or shared mutable state,
    checking the call sites is the right method.

    Your review is read-only on this checkout. Do not mutate the working
    tree, the index, HEAD, or branch state in any way.

    ## You Do Not Dispatch Subagents

    Do all of this review yourself. Never spawn a subagent to review part
    of the diff, and never spawn another reviewer for a second opinion.
    This process already provides every review seat the work gets; a
    reviewer you spawn duplicates one of them at full cost, and its
    verdict counts for nothing. If the diff feels too large for one
    pass, review it in passes yourself and say so in your report.

    ## Do Not Trust the Report

    Treat the implementer's report as unverified claims about the code. It
    may be incomplete, inaccurate, or optimistic. Verify the claims against
    the diff. Design rationales in the report are claims too: "left it per
    YAGNI," "kept it simple deliberately," or any other justification is the
    implementer grading their own work. Judge the code on its merits — a
    stated rationale never downgrades a finding's severity.

    ## Tests

    The implementer already ran the tests and reported results with TDD
    evidence for exactly this code. Do not re-run the suite to confirm their
    report. Run a test only when reading the code raises a specific doubt
    that no existing run answers — and then a focused test, never a
    package-wide suite, race detector run, or repeated/high-count loop. If
    heavy validation seems warranted, recommend it in your report instead of
    running it. If you cannot run commands in this environment, name the
    test you would run.

    Warnings or other noise in the implementer's reported test output are
    findings — test output should be pristine.

    Evidence you cannot see is not evidence that doesn't exist. If the
    report or its test evidence looks truncated, or you cannot locate the
    results it claims, re-read the file at its stated path — and if it is
    genuinely missing or garbled, report that as a gap for the controller.
    Re-running the suite to regenerate what you failed to read is not
    verification; illegibility of the evidence is not invalidation of it.

    ## Part 1: Spec Compliance

    Compare the diff against What Was Requested:

    - **Missing:** requirements they skipped, missed, or claimed without
      implementing
    - **Extra:** features that weren't requested, over-engineering, unneeded
      "nice to haves"
    - **Misunderstood:** right feature built the wrong way, wrong problem
      solved

    If the brief lists several files each with its own change (a batched
    dispatch), check the diff against that list file by file: every listed
    file must have its corresponding hunk. A listed file the diff never
    touches is a Missing finding, no matter how clean the rest of the
    batch looks.

    If a requirement cannot be verified from this diff alone (it lives in
    unchanged code or spans tasks), report it as a ⚠️ item instead of
    broadening your search.

    ## Part 2: Code Quality

    **Code quality:**
    - Clean separation of concerns?
    - Proper error handling?
    - DRY without premature abstraction?
    - Edge cases handled?

    **Tests:**
    - Do the new and changed tests verify real behavior, not mocks?
    - Are the task's edge cases covered?

    **Structure:**
    - Does each file have one clear responsibility with a well-defined interface?
    - Are units decomposed so they can be understood and tested independently?
    - Is the implementation following the file structure from the plan?
    - Did this change create new files that are already large, or
      significantly grow existing files? (Don't flag pre-existing file
      sizes — focus on what this change contributed.)

    Your report should point at evidence: file:line references for every
    finding and for any check you would otherwise answer with a bare
    "yes." A tight report that cites lines gives the controller everything
    it needs.

    Your final message is the report itself: begin directly with the
    spec-compliance verdict. Every line is a verdict, a finding with
    file:line, or a check you ran — no preamble, no process narration,
    no closing summary.

    ## Calibration

    Categorize issues by actual severity. Not everything is Critical.
    Important means this task cannot be trusted until it is fixed: incorrect
    or fragile behavior, a missed requirement, or maintainability damage you
    would block a merge over — verbatim duplication of a logic block,
    swallowed errors, tests that assert nothing. "Coverage could be broader"
    and polish suggestions are Minor.
    If the plan or brief explicitly mandates something this rubric calls a
    defect (a test that asserts nothing, verbatim duplication of a logic
    block), that IS a finding — report it as Important, labeled
    plan-mandated. The plan's authorship does not grade its own work; the
    human decides.
    Acknowledge what was done well before listing issues — accurate praise
    helps the implementer trust the rest of the feedback.

    ## Output Format

    ### Spec Compliance

    - ✅ Spec compliant | ❌ Issues found: [what's missing/extra/misunderstood,
      with file:line references]
    - ⚠️ Cannot verify from diff: [requirements you could not verify from the
      diff alone, and what the controller should check — report alongside the
      ✅/❌ verdict for everything you could verify]

    ### Strengths
    [What's well done? Be specific.]

    ### Issues

    #### Critical (Must Fix)
    #### Important (Should Fix)
    #### Minor (Nice to Have)

    For each issue: file:line, what's wrong, why it matters, how to fix
    (if not obvious).

    ### Assessment

    **Task quality:** [Approved | Needs fixes]

    **Reasoning:** [1-2 sentence technical assessment]
```

**Placeholders:**
- `[MODEL]` — REQUIRED: reviewer model per SKILL.md Model Selection
- `/Users/lihongwei/Desktop/晾念头 : Thoughtline/app/.superpowers/sdd/LOCALE-APPEARANCE-PLAN/task-1-brief.md` — REQUIRED: the task brief file (`bash scripts/task-brief PLAN N`
  prints the path; same file the implementer worked from)
- `# Binding global constraints

- Desktop resident view contains only rope, clips and paper. Put language and appearance controls at the top right of the first-level Composer, Detail and Calendar, before close, in a consistent visible position. Never put controls above the rope or hide the only entry in Settings/More.
- Two restrained sliding capsules: fixed `中 / EN` language labels, thin SVG sun/moon appearance symbols; no flags or large backing toolbar. Concept sizes: language about 88×30 DIP, appearance about 72×30 DIP, total about 168 DIP, desktop hit height about 36 DIP. At widths 350/380/480/740, shorten the title before hiding either control or close; no horizontal overflow. Every icon has complete tooltip and accessible name.
- First new profile: Chinese OS languages select `zh-CN`, other languages select `en`; an existing profile with no preference stays Chinese. Appearance starts following OS; manual sun/moon selection overrides it, secondary Settings offers Follow system again. Persist in a separate profile-level preference file to avoid incrementing note snapshot revisions or conflicting with live autosave. Keep schema3 note structure/IDs/dates unchanged and do not overwrite hotkeys, storage paths or other settings.
- Translate app labels, hints, errors, empty states, hover/focus tooltips, tray/context menus, settings, destructive confirmations and calendar formats/plurals. Use centrally maintained typed keys and placeholders. Never translate/rewrite user note title/body/project/custom Agent names. Localize system General/Ungrouped by system IDs. Locale/theme updates do not remount views, steal editor focus, lose selection/scroll/IME candidates or overwrite dirty content.
- Light: warm paper and ink teal. Dark: deep blue gray surfaces, dim warm gray paper and warm pale text, with small coral accents. Main paper, all auxiliary views, settings, popovers/tooltips/menus follow the effective theme. Text contrast at least 4.5:1; retain visible focus/selected states in high contrast/forced colors. Reuse approved logo/clip assets unchanged. Existing vibrancy/acrylic fallback is not native Liquid Glass. Never change OS settings.
- Smooth short tactile slide: slight press compression, continuous pointer-following thumb, gentle settling on release, click animates too. Aim about 140–180 ms; any measured adjustment is recorded. Reverse from the current visual position immediately. No infinite/long motion or blocked input; correctness never waits for animation end. Click/drag/keyboard arrows/Home/End work; threshold about 12 DIP; Escape/pointercancel restores committed choice. Reduced motion and forced colors suppress decorative movement, preserving all operations. All switch hit regions are no-drag.
- Validate preference payloads and sender ownership, serialize/sequence concurrent writes and refuse stale callbacks. Failed persistence visibly retains/reverts to the last durable preference while protecting edit content. Corrupt/unreadable preference files must be preserved and surfaced, not silently overwritten. First-profile detection must precede creation of a new snapshot and must not read user note contents merely to decide language.
- Mac and Windows are verified separately. Controlled DOM/source/CI checks do not prove physical IME, DPI, multi-display, focus, natural motion or WeChat/Doubao/WorkBuddy reception. Never send to real conversations, silently copy/paste, request extra OS permissions, modify the user's installation or make the repository public.
- Use isolated synthetic profiles. Protect existing Electron PID30628, real data, original `out`/dependencies and other worktrees. Prefer a separate temporary build output for tests. Restore injected faults and held replies, finish composition/save/flush, close and quit normally, then remove only owned temporary processes/directories. Retain failed logs, exact source inputs and necessary screenshots; no assertion weakening.
- User/repository authorize validated stages on main, push and new private preview packages. No force/reset/history rewrite/G7 integration. Use new `0.0.17-preview.3` for this increment; never reuse .2/.16 tags or replace installed apps. Run Node24.19.0 from bundled runtime, explicit valid workdir and `/bin/sh` login false.

` — the binding requirements copied verbatim from
  the plan's Global Constraints section or the spec: exact values, formats,
  and stated relationships between components (not process rules — those
  are already in this template)
- `/Users/lihongwei/Desktop/晾念头 : Thoughtline/app/.superpowers/sdd/LOCALE-APPEARANCE-PLAN/task-1-report.md` — REQUIRED: the file the implementer wrote its detailed
  report to
- `713a1fe30482930b24a23b40f2d75ac495057a40` — commit before this task
- `d489b1deed3992fd577da87d390dbc6bddabed3b` — current commit
- `/Users/lihongwei/Desktop/晾念头 : Thoughtline/app/.superpowers/sdd/LOCALE-APPEARANCE-PLAN/task-1-production.diff` — REQUIRED: the path the controller wrote the review
  package to (`bash scripts/review-package PLAN_FILE BASE HEAD` prints the unique
  path it wrote; the package never enters the controller's context)

**Reviewer returns:** Spec Compliance verdict (✅/❌/⚠️), Strengths, Issues
(Critical/Important/Minor), Task quality verdict

Controller packaging note: Complete archive diff is review-713a1fe..d489b1d.diff (2.9MB, most is duplicated historical evidence patches). The production diff above contains EVERY changed source/test/build/delivery/planning/QA file, excluding acceptance/evidence only. Use it once for code review; inspect specifically claimed logs/receipts directly for concrete evidence risks, rather than re-ingesting historical source patch duplication. Full archive is available if needed. Root independently checked final23 recorded PIDs exited and synthetic profiles/build absent;30628alive. Two startup-only forced kills explicitly remain failures; never count them as passed. New video CSS-material idea is evaluation only, no production change for this increment. README promotional GIF deferred by user.
Write full read-only review to task-1-review.md in THIS SDD workspace (only report-file write allowed); final message compact spec/quality/finding counts/report path. No subagents, no full tests, no push or mutation. Explicit valid workdir and Node24 PATH if any narrowly justified command.
