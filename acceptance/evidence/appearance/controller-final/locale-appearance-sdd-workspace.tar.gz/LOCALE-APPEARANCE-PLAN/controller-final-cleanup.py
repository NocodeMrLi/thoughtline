# -*- coding: utf-8 -*-
from pathlib import Path
import os, json, hashlib, subprocess, shutil, datetime
w=Path(__file__).resolve().parent
root=Path((w/'task-2-owned-root.txt').read_text().strip())
expected='/tmp/thoughtline-task2-KnsYFP'
clone=root/'owned-project'
assert str(root)==expected and root.is_dir() and not root.is_symlink()
assert str(root.resolve())=='/private/tmp/thoughtline-task2-KnsYFP'
def out(args): return subprocess.check_output(args,text=True)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()
assert out(['git','-C',str(clone),'rev-parse','HEAD']).strip()=='01017c9525ac971b6e97461ef2910140944eda19'
assert not out(['git','-C',str(clone),'status','--porcelain']).strip()
own={os.getpid()}; p=os.getppid()
while p>1 and p not in own:
 own.add(p)
 p=int(out(['ps','-p',str(p),'-o','ppid=']).strip() or '0')
def active():
 result=[]
 for line in out(['ps','-axo','pid=,command=']).splitlines():
  bits=line.strip().split(None,1)
  if len(bits)<2: continue
  pid=int(bits[0])
  if pid in own: continue
  if str(root)+'/' in bits[1] or str(root.resolve())+'/' in bits[1]: result.append({'pid':pid,'command':bits[1]})
 return result
assert not active(), active()
mounts=out(['hdiutil','info'])
assert 'thoughtline-task2-' not in mounts and 'thoughtline-portable-' not in mounts
os.kill(30628,0)
delivery=Path('/Users/lihongwei/Documents/Codex/2026-10-09/thoughtline-round1-repair/delivery/v0.0.17-preview.3')
gate=json.loads((w/'controller-final-prepublication-audit.json').read_text())
assert len(gate['files'])==24
for f in gate['files']:
 p=delivery/f['name']; assert p.is_file() and not p.is_symlink()
 assert p.stat().st_size==f['bytes'] and sha(p)==f['sha256']
records=[]; logical=allocated=0
for directory, dirs, files in os.walk(root,followlinks=False):
 for name in list(dirs):
  p=Path(directory)/name
  if p.is_symlink():
   records.append({'path':str(p.relative_to(root)),'symlink':os.readlink(p)}); dirs.remove(name)
 for name in files:
  p=Path(directory)/name
  if p.is_symlink(): records.append({'path':str(p.relative_to(root)),'symlink':os.readlink(p)}); continue
  stat=p.stat(); logical+=stat.st_size; allocated+=stat.st_blocks*512
  records.append({'path':str(p.relative_to(root)),'bytes':stat.st_size,'allocatedBytes':stat.st_blocks*512,'sha256':sha(p)})
inventory={'state':'owned clone inventory BEFORE removal','at':datetime.datetime.now().isoformat(),'root':str(root),'realRoot':str(root.resolve()),'frozenSource':'01017c9525ac971b6e97461ef2910140944eda19','records':records,'recordCount':len(records),'logicalBytes':logical,'allocatedBytes':allocated,'excludedOwnAncestorPids':sorted(own),'remainingCloneProcesses':active(),'published24FilesPreserved':True,'protectedPid30628Alive':True}
(w/'controller-own-clone-cleanup-inventory.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2)+'\n')
assert not active(), active()
os.kill(30628,0)
shutil.rmtree(root)
assert not root.exists()
os.kill(30628,0)
receipt={k:v for k,v in inventory.items() if k!='records'}
receipt.update({'state':'owned frozen clone removed after no process/no mount/clean Git and full published24 hash guards','removed':True,'signalsSent':0,'realDataTargeted':False,'originalOutDependenciesCachesTargeted':False,'gitWorktreesTargeted':False,'inventory':'controller-own-clone-cleanup-inventory.json','inventorySha256':sha(w/'controller-own-clone-cleanup-inventory.json')})
(w/'controller-own-clone-cleanup-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='excludedOwnAncestorPids'},ensure_ascii=False))
