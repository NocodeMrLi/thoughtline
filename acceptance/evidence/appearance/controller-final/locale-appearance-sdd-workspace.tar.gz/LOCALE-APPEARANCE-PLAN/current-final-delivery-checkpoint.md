## 当前交付：私有 preview.3 已发布（2026-10-10）

**开发与受控交付完成，独立实体验收待进行。** [下载 v0.0.17-preview.3](https://github.com/NocodeMrLi/thoughtline/releases/tag/v0.0.17-preview.3)，私有仓库保持 PRIVATE。发布 ID408155486，发布时间2026-10-09T18:56:29Z；新 tag、实际 Mac／Windows 包和清单均绑定冻结源码 `01017c9525ac971b6e97461ef2910140944eda19`。后续 README、证据和文档提交不是安装包源码。

| 平台 | 安装包 | 字节 | SHA256 |
|---|---|---:|---|
| macOS arm64 | Thoughtline-0.0.17-preview.3-mac-arm64.dmg | 133417660 | `4799af1772eff9d013942d207c6235cce6a239ef89f3a2910994ef2ff5758a3d` |
| Windows x64 | Thoughtline-0.0.17-preview.3-win-x64.exe | 113101943 | `68c6f4f1f35a5ded1c8d1a04e3c063c4d372fd003fba73ceaa4e77c7921da235` |

本地目录：`/Users/lihongwei/Documents/Codex/2026-10-09/thoughtline-round1-repair/delivery/v0.0.17-preview.3`。完整24文件，23项 SHA256SUMS、22项清单非自身哈希已回读；发布前真实下载证明、发布后全部附件 ID／大小／digest、PRIVATE、新tag及旧preview.2／preview.6未改均核对。227项规范输入 SHA256 `72314079c3dbfb77ef813a5d4c852e9eb46fe2ab85d1b45e671acaedf49242f9`；Mac原始向量 `5a030846d935c3b6d38d690b76a5ff0a14d654fd2a62b5f152f0844bfa492431`，Windows原始向量 `315b609c42c0c9a219c94e66da2a302a03250d1d4fd23ccd2852bcb671db3736`。全部227 mode/blob及各端实际捕获对应；未将后续文档 HEAD 冒作构建来源。

### 方案／实施状态

原第一轮11项修复已在preview.2实施；preview.3加入中英全界面、首层中/EN与太阳/月亮滑动胶囊、跟随系统、独立顺序偏好保存。新建／展开／日历右上角直接可见；常驻主界面仍只有绳、夹子、纸张。项目叉号即时删除，完成和退出都不恢复；未分组不可删，念头保留，整理撤销不复活已删分组。日历使用获认可Logo红夹子，日/月/年进入与返回保留可打断短缩放，纸张薄、柔和、哑光。

双端已实现协调的日夜配色和现有Mac vibrancy／Windows acrylic及不透明降级；进一步玻璃打磨仍属独立评估，不冒称原生Liquid Glass，不把纸做成玻璃。README七份语言描述及preview徽章已更新为真实中英功能；七种README语言不等于七种应用语言。用户要求宣传展示图／GIF完工并独立验证后再制作，本次保持图像字节。

### 测试证据

Mac15.3.1／Darwin24.3.0 arm64、Node24.19／Electron44.7：226单测通过、4Windows专用跳过，类型／构建通过；源主外观20＋修复11项；实际挂载包6项数据检查（含完整备份恢复后两次重启）＋3项外观检查。新真实DMG及生成启动器搬到含空格、中文、单引号目录，从不同cwd检查相邻DMG、缺失／损坏和profile符号链接：正常0，拒收1；原生产包可用时也不会回退误用它。

Windows hosted Server2025 build26100 x64：[CI37974164754 attempt1](https://github.com/NocodeMrLi/thoughtline/actions/runs/37974164754)成功，冻结源一致，230单测、类型／构建、源20＋11及原源流程通过；实际NSIS安装schema2／保存／备份／重启、实际外观3项、同版本重装和普通卸载保数据通过。此CI不能替代Windows实机。Mac严格ad-hoc、未Developer ID／公证；Windows安装器及App未签名，系统安全保护未关闭。

源码唯一终审修复限定复审、CRLF夹具复审、启动器复审及最终真实双包消费复审均通过，剩0Critical／0Important／1非阻断Minor（Windows DEP0190，来源未证明，不隐藏告警）。最终消费者复审后的四份元数据已实际上传／下载比对，再发布。证据： [新双包报告](evidence/appearance/task2-final-rebuild-01017c9/task-2-report-copy.md)、[最终消费复审](evidence/appearance/controller-final/task-2-final-consumer-review.md)、[发布核对](evidence/appearance/controller-final/controller-final-publication-audit.json)、[清理清单](evidence/appearance/controller-final/controller-own-clone-cleanup-receipt.json)。

最后本轮Mac受控测试64个自建进程（63 App＋1监督器）和7个profile已退出／清理；自建临时构建目录18555条记录逐项归档哈希后清理，未发送信号。原PID30628仍在，现有安装、真实数据、原out／依赖／缓存及另外11工作树受保护。此前失败与两例被迫清理的启动测试记录保留，不能概括所有历史为正常退出。仅清理本轮自建重复文件；不清空废纸篓。

### 剩余问题／独立测试

真实Mac与Windows输入法、100%／125%／150%DPI、多屏／断开副屏、焦点、窗口拖动、系统辅助设置和材质／动画手感待分别验证。微信4.1.13.65成功、QQ浏览器豆包间歇、WorkBuddy5.7.6持续失败仍是用户反馈，真实接收框重复外拖独立未测；Windows版本、QQ浏览器版本和起拖点未知。不得宣布WorkBuddy不支持或已修复，不自动发送、覆盖草稿、抢焦点或失败后改剪贴板。

独立测试请用完整同版目录和隔离入口，先看实际QA指南。Mac由`/bin/zsh ./Start-Thoughtline-Isolated-Mac.command --check-only`核验，再去掉参数启动；下载权限位不作为前提。Windows相同App标识安装器可能覆盖已有安装，应在独立测试环境操作。按[增量QA表](LOCALE-APPEARANCE-INDEPENDENT-QA.md)及[原轮QA表](ROUND1-INDEPENDENT-QA.md)，报告优先级、条件、步骤、预期／实际、证据和连续测试成功率；保留所有失败。

schema3、新profile preferences.json与念头备份分开、迁移／恢复／回滚限制见[数据安全](../docs/ROUND1-DATA-SAFETY.md)。当前无一键备份恢复按钮；preview.2仍支持schema3但不消费新界面偏好，preview.6只可在独立目录用升级前备份验证，其不包含升级后修改。进一步材质打磨和README交互GIF后置；用户验收未宣称通过。
