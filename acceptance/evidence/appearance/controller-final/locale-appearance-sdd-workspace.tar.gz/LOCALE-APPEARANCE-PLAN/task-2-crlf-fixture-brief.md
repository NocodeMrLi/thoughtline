# Task2 included fixture portability repair

Base: `65b7ea80462d68aef8b0935a24ab821797d3e564`, clean main. Read `global-constraints.md` first; this brief is binding for this repair.

The renewed Windows consumer run37968756145 from source3fa4683 failed 222pass/4fail before package build. All four stacks are tests/unit/preferenceOrdering.test.ts:8:84 null match. Local controlled LF/CRLF behavior identifies a fixed-LF extraction defect; runner file bytes are absent, so keep actual failure versus mechanism inference distinct. Read acceptance/evidence/appearance/task2-final-rebuild-3fa4683/windows-unit-failure-audit.json and matching failure log.

Repair only the included unit fixture `tests/unit/preferenceOrdering.test.ts`. Do not change production callback/helper or weaken any latest IO/rejection/own-broadcast/other-window/newer-intent assertions. Extract unchanged production callback across both LF and CRLF. Make the existing four behavioral tests run against both source EOL forms (normalize fixture source to chosen EOL in memory, not files). A clear missing-callback assertion is useful; avoid production logic duplication or test that merely mirrors helper. Retain the source callback itself as test input.

Capture exact controlled RED for CRLF cases before the extraction repair, GREEN for all LF+CRLF behavior cases after, with source bytes and command/exit/count. Run typecheck and appropriate unit checks once after final change; no repetitive full suite, Electron or package runs unless a new concrete failure requires them. Subsequent fresh dual build will perform the required consumers. Record complete source vector and exact included-file diff. Preserve CI failure evidence.

You are sole source/index writer until reporting. Root only writes ignored ledger and external project notes. Commit source fixture plus only owned evidence under acceptance/evidence/appearance/task2-crlf-fixture. No push, CI, draft/tag/release, build, external docs, .planning or controller ledger changes. Protect original out/deps/PID30628 and all worktrees. No subagents. No global clipboard/input/app or OS action.

Full report: `.superpowers/sdd/LOCALE-APPEARANCE-PLAN/task-2-crlf-fixture-report.md`; include command/output evidence, RED/GREEN, assertions unchanged, source vector, exact SHA, no physical platform claim, cleanup and concerns. Return concise DONE/status/commits/tests only. A focused independent Task2 fixture review follows before new exact source freeze and BOTH packages rebuild; no broad final review is repeated.
