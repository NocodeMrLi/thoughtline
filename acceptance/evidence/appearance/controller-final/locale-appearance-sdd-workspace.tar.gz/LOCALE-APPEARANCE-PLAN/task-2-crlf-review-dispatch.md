# Task2 fixture portability scoped review

Read first task-2-crlf-fixture-brief.md and global-constraints.md. Report task-2-crlf-fixture-report.md; diff and exact HEAD are supplied after source writer handoff. Review ONLY the included fixture change and its claimed RED/GREEN/evidence. The full final production review and its ONE fix/scoped review are complete; this is a newly blocked Task2 unit-fixture portability consumer gate.

Finding to verdict verbatim: Windows CI37968756145 from frozen3fa4683 fails all four new preferenceOrdering callback tests at line8:84 null-match. The extraction regex uses a literal LF terminator; local LF matches but the same source converted to CRLF does not. Preserve the unchanged production callback and all IO/rejection/latest-intent/own-broadcast/other-window assertions while supporting LF and CRLF.

Read-only checkout; no working tree/index/HEAD/branch mutation. Do not run the suite, Electron, CI, package builds, or broad unrelated review. Confirm test commands/output/source vector in existing report; only a focused probe for a concrete unanswered doubt. No subagents.

Verdict the finding ADDRESSED/NOT ADDRESSED with file:line; state new Critical/Important/Minor breakage in this diff, out-of-scope observations, explicit Spec and Quality verdicts. Record requirements not verifiable from this narrow diff (e.g actual new dual packages) so root routes them to Task2 package consumer after newfreeze, not presumed passing. Full report to task-2-crlf-fixture-review.md and short return.
