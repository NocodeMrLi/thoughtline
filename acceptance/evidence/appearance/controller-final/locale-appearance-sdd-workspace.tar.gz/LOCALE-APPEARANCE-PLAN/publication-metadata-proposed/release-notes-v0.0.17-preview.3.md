# Thoughtline 0.0.17-preview.3 — private preview for independent testing

This candidate adds Chinese/English UI and day/night appearance controls in the Composer, Detail and Calendar windows, with Follow system in Settings. Preferences persist separately from notes; user text and custom names are preserved. The desktop paper remains matte.

Both packages were rebuilt from frozen source `4191fd82d965641a803d994644993fc9426e7c40` (227-input canonical vector `10367d7b3dc5d920af5e781b13b9daa1848e273cec4c542d5e652a198a68dffa`). Mac arm64 DMG and Windows x64 NSIS installer passed isolated actual-package checks, including English/dark persistence across restart; the Windows runner also passed same-version reinstall and ordinary-uninstall data preservation. See `QA-guide-v0.0.17-preview.3.md`, `release-manifest.json` and `SHA256SUMS` before testing.

Mac is ad-hoc signed and not notarized. Windows app and installer are unsigned. The Windows installer uses the existing app identity and may replace an installed version: use a separate test environment. Physical IME, DPI, multi-display, focus, natural motion and real WeChat/Doubao/WorkBuddy reception are still open for independent acceptance. This is a private prerelease for independent testing after the source review, scoped repairs and paired package gates. Physical acceptance and real receiver testing remain pending.
