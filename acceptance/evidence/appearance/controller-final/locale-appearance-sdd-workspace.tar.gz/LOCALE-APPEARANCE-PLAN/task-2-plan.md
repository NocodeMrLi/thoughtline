# Task 2 delivery ledger

Owner: package verification and private draft only. Immutable build source `3cb50bb10572559c9ef4593542def35179c28f10`; canonical vector `2bb6af24495e914ff333886348f6077135682ff2f7506c14e40b9360ab3f95fc` (222 files).

1. Verify source, repository privacy, scripts, prior delivery format and protection boundaries. **Complete.** Main clean, ahead six; repo private; original Electron PID 30628 present. Node 24.19.0. Original out and dependencies stay untouched.
2. Push exact main and inspect matching Windows CI. **In progress.** Pushed 3cb50bb; automatic run 37960611892 attempt 1 is in progress.
3. Prepare detached owned clone and run Mac verification/package and actual packaged fixtures serially. **Complete.** Owned clone `/tmp/thoughtline-task2-KnsYFP/owned-project`; exact 222-input vector. `npm run verify` passed 212 units/4 Windows skips. DMG SHA256 `40661757c4bf5d993f339a01087461da860d07d8b60e6e96c4b2ab21268ed128`, asar `b4883ddd55decc4eabc57b2956aeef5e5e5084b1ed259b6caa42753867f9ff6b`. Mounted App strict signature verified. Actual package acceptance 6/6, packaged appearance 3/3, all normal quits and cleanup. DMG mount detached. Mac launcher generated and `--check-only` passed.
4. Inspect Windows job, download and audit actual installer/evidence. **Pending.**
5. Assemble checksummed delivery, private draft and task report; verify exact remote assets. **Pending.**

Errors: Initial `gh run view --json artifacts` failed because `artifacts` is not a supported field; corrected query. First `/usr/bin/shasum` invocation failed under inherited unsupported `C.UTF-8` locale; reran hash with `LC_ALL=C LC_CTYPE=C LANG=C`, matched manifest exactly. No package or test assertion changed.

## Reviewed rebuild attempt, 2026-10-10

Source HEAD `d9cf75b425464589e6761abd8dff9954f3e2ad0c`; 225 canonical inputs `7b658b2d8a88b499c722bfe51a9bba0889b13673e0ee0661364f4eb5129764cc`, Mac raw `c92393d605869b6f7003d315ca05414287eff24b98bd0f25c5218acd2c4a8992`.

1. Read reviewed fixture repair/new freeze and push exact source. **Complete.** Private main pushed; automatic Windows run to identify and reuse.
2. Preserve old blocked 3cb delivery before new artifact naming. **Complete.** Atomic move to sibling `failed-attempt-3cb50bb-v0.0.17-preview.3`, all 11 file hashes/bytes verified, original 10 partial checksum targets passed. Mapping receipt `task-2-old-partial-mapping.json`.
3. Safely checkout owned clone at new detached source, verify dependencies/vector, run Mac verify/package and serial actual package fixtures. **Complete.** `npm run verify` 216 passed/4 Windows-only skipped, 38 suites passed/1 skipped. New DMG SHA256 `9c33bd508978b12a6367941b079e995087fe68be2a1c54df69a658c56c3cd2ac` (133417388 bytes), new source225 vector, strict ad-hoc signature, asar `b4883ddd55decc4eabc57b2956aeef5e5e5084b1ed259b6caa42753867f9ff6b`; actual mounted package acceptance6/6 and new supervisor appearance3/3, normal quit/cleanup, mount detached. New ASCII Mac launcher check-only passed.
4. Inspect matching Windows run, actual test trees, preflight and installer artifact; audit source/PE/signature/hash. **In progress.** Automatic run 37963724007, exact d9cf75b SHA, NSIS build currently in progress; no duplicate dispatch.
5. Assemble new final delivery, checksum every asset, stage private draft only after all gates; report and evidence commit. **Pending.**

### Rebuild completion readback

- Windows automatic run `37963724007` attempt 1 **success**; 220 units, source appearance 17/17 and fix 11/11, downloaded NSIS `ad5401e0...`, installed package appearance 3/3, install/reinstall/ordinary uninstall data checks and cleanup passed. Full 225-input source/fixture/PE audit saved.
- New delivery directory has both builds and **23/23** complete SHA256SUMS targets. Private draft release ID `408155486`, source target `d9cf75b`, **13/13** uploaded assets downloaded again and byte-hash matched; unpublished draft only.
- Exact owned duplicate cleanup freed **1,494,675,456 allocated bytes** with path/hash inventory in `task-2-rebuild-cleanup.json`. Old failed candidate and original PID 30628 protected. Full report appended to `task-2-report.md`; task-owned evidence commit and controller final review remain handoff steps.

Task2 producer handoff complete: evidence-only commit/push `ff36152e5504ce2563d091e90e5eca4000684089`, clean local/remote main; packages and draft remain bound to source `d9cf75b425464589e6761abd8dff9954f3e2ad0c`. Release ID 408155486 is still private draft/prerelease with 13/13 assets; tag ref absent. Controller review/publication remain pending.

### Draft asset completeness repair

Controller identified an initial 13/24 remote-asset gap while draft remained unpublished. Preserved the 13-asset checkpoint; added 11 missing evidence assets and replaced only manifest/SHA256SUMS. Complete remote set is now **24/24**, local checksum targets **23/23**, 13 new/replaced remote bytes downloaded and verified, unchanged 11 revalidated against prior downloads and current API digest/size. Updated tracked evidence includes complete release readback and full cleanup receipt. No source/package rebuild or included input change.

Completeness repair handoff commit/push: `f1351cc0bb2deb3c9ef07cd385d5283160d74f85` (evidence only, clean main/origin). Complete private draft remains ID 408155486, 24 uploaded assets, 23 passing checksum targets; source/package target d9cf75b unchanged. Controller final review/publication pending.

### Final-fix source consumer attempt `3fa4683` — blocked

Archived old complete d9cf 24-file candidate and exact private-draft snapshot; pushed exact reviewed 3fa source with 227 frozen inputs. Owned clone dependencies pass `npm ls`; Mac verify 222 passed/4 skipped, new DMG `d2184c62…` mounted App 6/6+3/3 and cleanup passed. Matching automatic Windows run `37968756145` failed in included `tests/unit/preferenceOrdering.test.ts:8` with four null-match errors (222 pass/4 fail) before NSIS. No draft/tag update or Windows installer. Partial new Mac candidate archived under `blocked-final-rebuild-3fa4683-v0.0.17-preview.3`, 12/12 partial checksums. Preserve clone deps/out for next reviewed repair; evidence/report commit and source-fix handoff pending.

Blocked-attempt evidence handoff complete: `65b7ea80462d68aef8b0935a24ab821797d3e564` pushed, clean main/origin, source remains 3fa4683, old d9cf draft unchanged and unpublished. Sole Git/index control returns to controller for reviewed included-fixture repair; Task2 awaits a new exact freeze for both package rebuilds.

### Reviewed 4191fd8 paired rebuild

Exact source `4191fd82d965641a803d994644993fc9426e7c40`, 227 canonical `10367d7b3dc5d920af5e781b13b9daa1848e273cec4c542d5e652a198a68dffa`, Mac raw `4a5c3b3d596a9ea1c3342f69af7d01beafe56dd83712781d48fc87410fa9bcef`. Pushed once; matching automatic Windows run `37970340295` in progress, verify/source Electron/source appearance20+repair11 steps success, NSIS step underway; no duplicate run. Owned clone reused deps/out with `npm ls` pass. Mac verify 226 pass/4 Win-only skip; new DMG 9c2096b5..., mounted asar72326b5e..., 33 files match, strict ad-hoc, actual package6+appearance3 pass, normal quit/profile absent, mount detached, ASCII launcher check-only pass. Draft408155486 still oldd9cf24, no tag/publication. Pending Windows installer/actual preflight, full24 delivery, draft update/readback, evidence commit and cleanup.
