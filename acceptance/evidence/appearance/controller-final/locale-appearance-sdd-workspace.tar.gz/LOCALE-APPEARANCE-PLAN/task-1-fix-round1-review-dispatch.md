# Scoped Re-Review Prompt Template

Use this template when dispatching a re-review after a fix round. The
re-reviewer verifies the findings were addressed and checks the fix diff for
new breakage. It is not a fresh review — the full review already happened.

**Purpose:** Verify each finding from the previous review was addressed, and
that the fix itself broke nothing.

```
Subagent (general-purpose):
  description: "Re-review Task N fix round R"
  model: [MODEL — REQUIRED: choose per SKILL.md Model Selection; an omitted
         model silently inherits the session's most expensive one]
  prompt: |
    You are re-reviewing one task's fix round. A previous review produced
    findings; an implementer has attempted to fix them. Your job is to
    verdict each finding and inspect the fix diff — nothing else.

    ## The Task

    Read the task brief: /Users/lihongwei/Desktop/晾念头 : Thoughtline/app/.superpowers/sdd/LOCALE-APPEARANCE-PLAN/task-1-brief.md

    ## The Findings Under Verification

    # Task1 fix round1 findings — verbatim reviewer findings

1. **Recompute custom Agent label ink for the new dark paper.** `src/renderer/styles/preferences-theme.css:3` changes dark paper to `#383831`, but `src/renderer/components/ClipCard.tsx:14` still obtains label colors from `src/renderer/components/agentInk.ts:2`, which calculates against the old light gray dark-paper RGB `[179,175,162]`. The applied dark label selector is `src/renderer/styles/overlay.css:88`. A custom Agent with `#4C90D9` gets dark ink `#17416e`, giving **1.1347:1** against the new paper; `#8AADD4` gives **1.1290:1**. This makes the Agent/project line on night-mode rope papers difficult to read and violates the required 4.5:1 contrast. The final appearance test measures only Composer textarea and primary button (`tests/electron/appearance-workflow.cjs:20`), so its passing result does not cover this regression. Update the algorithm/shared palette for the actual light and dark paper colors, allowing lighter ink on dark paper; verify rendered custom Agent labels with representative saturated and neutral colors while preserving the approved clip artwork and user-specified clip color.

2. **Render all Shelf status/error messages through the current locale.** `src/renderer/components/Shelf.tsx:90` outputs `{error||notice}` directly. Several existing handlers still assign Chinese strings, such as the canceled drag at line 66, while the newly translated drag-success messages at lines 58–63 are inside the once-installed event effect ending at line 70 and therefore capture the initial `t`. Reproduction from the code: start an existing Chinese profile, switch to English in Composer/Calendar, then successfully move a rope clip; the completion notice remains Chinese. On an initially English profile, dragging out of bounds still uses the literal Chinese cancellation string. Lower-layer errors have the same bypass. Use the current render-time message boundary or stable message keys/parameters for Shelf notices/errors; do not re-register or cancel live drags merely to change language. Add focused coverage for switch-then-drag completion, cancellation, and a failed page/save operation. The current coverage claim at `acceptance/evidence/appearance/visible-string-coverage.md:14` is broader than the implementation.

3. **Make the error boundary complete and preserve diagnostic bytes instead of matching arbitrary UI templates.** `src/shared/i18n.ts:12` builds reverse regexes for every dictionary template and line 14 applies them to app errors/unknown diagnostics. It has special handling for storage migration and file-mismatch prefixes, but not the actual repository IO shape at `src/main/store/repository.ts:6` (`本地保存未成功，请保留文字并重试。 (${diagnostic})`) or the main storage catch with a suffix (`src/main/index.ts:277`). A focused probe with `本地保存未成功，请保留文字并重试。 (ENOSPC /用户/原始中文)` does not produce the English app message; it remains Chinese with its comma changed. Worse, the generic `dayCount` template matches any Chinese comma, so the diagnostic `ENOENT: open '/用户/原始，中文.json'` becomes `ENOENT: open '/用户/原始, 中文.json'`. This violates both English error coverage and the explicit requirement to preserve diagnostic paths. Prefer typed app errors with separate diagnostic slots, or restrict deliberate reverse mapping to complete known error envelopes and leave their diagnostic payloads untouched. Cover actual repository IO suffixes, startup propagation, the outer main-process storage catch, and diagnostics containing Chinese/ASCII punctuation. The existing nested-storage test (`tests/unit/i18n.test.ts:7`) covers a different prefix and misses this boundary; `acceptance/evidence/appearance/visible-string-coverage.md:16` currently overstates completeness.


## Confirmed cross-task readiness gap

- ⚠️ Cross-task delivery readiness: `scripts/generate-mac-isolated-launcher.cjs:14` still emits `启动${version}隔离体验.command`, while `docs/LOCALE-APPEARANCE-PLAN.md:44` requires `Start-Thoughtline-Isolated-Mac.command` with consistent generator/output names. Resolve this before freezing Task 2 inputs, or explicitly arrange a consistent final asset transformation without claiming an unchanged generator already satisfies it. This is a Task 2 readiness observation, not a fourth Task 1 finding.

Controller resolution: change the active Mac launcher generator to produce ASCII Start-Thoughtline-Isolated-Mac.command consistently before source freezing and both builds; preserve already delivered .2/.16 output files and rollback guide. This is required producer-input readiness, not a fixture-only post-freeze repair. Add covering generator/manifest check without recreating old release assets.

Minor retained/deferred: final validation warning noise accurately labeled; do not rerun full suite solely for cosmetics or enable broad output emptying. Historical missing inventories/out-preflight hash gaps remain explicitly unverified, never retroactively invented. Package/Windows/physical gates belong downstream.


    ## The Fix

    Read the implementer's report (fix reports are appended at the end):
    /Users/lihongwei/Desktop/晾念头 : Thoughtline/app/.superpowers/sdd/LOCALE-APPEARANCE-PLAN/task-1-report.md

    **Fix base:** d489b1deed3992fd577da87d390dbc6bddabed3b (the head the previous review saw)
    **Head:** 7de6eab012bc40ed812115d2f4bebe8f26d65634
    **Diff file:** /Users/lihongwei/Desktop/晾念头 : Thoughtline/app/.superpowers/sdd/LOCALE-APPEARANCE-PLAN/task-1-fix-round1-production.diff

    Read the diff file once — it contains the fix commits, a stat summary,
    and the fix diff with surrounding context. Do not re-run git commands.
    If the diff file is missing, fetch the diff yourself:
    `git diff --stat d489b1deed3992fd577da87d390dbc6bddabed3b..7de6eab012bc40ed812115d2f4bebe8f26d65634` and
    `git diff d489b1deed3992fd577da87d390dbc6bddabed3b..7de6eab012bc40ed812115d2f4bebe8f26d65634`.

    Your review is read-only on this checkout. Do not mutate the working
    tree, the index, HEAD, or branch state in any way.

    ## You Do Not Dispatch Subagents

    Do all of this review yourself. Never spawn a subagent to review part
    of the diff, and never spawn another reviewer for a second opinion.
    This process already provides every review seat the work gets; a
    reviewer you spawn duplicates one of them at full cost, and its
    verdict counts for nothing. If the diff feels too large for one
    pass, review it in passes yourself and say so in your report.

    ## Scope

    Your scope is the findings list and the fix diff. Verdict every finding.
    Inspect the fix diff for new problems the fix itself introduced. Do NOT
    re-review code the fix did not touch: if you notice an issue entirely
    outside the fix diff, report it under Out-of-Scope Observations — it
    does not block this task and does not extend the loop. A broad
    whole-branch review happens after all tasks are complete.

    ## Tests

    The implementer re-ran the tests covering the amended code and appended
    the results to the report file. Treat the report as unverified claims:
    confirm the fix report names the covering tests and shows their output,
    and verify the claims against the diff. Do not re-run the suite to
    confirm their report. Run a test only when reading the code raises a
    specific doubt that no existing run answers — and then a focused test,
    never a package-wide suite.

    ## Output Format

    Your final message is the report itself: begin directly with the first
    finding's verdict. Every line is a verdict, a finding with file:line,
    or a check you ran — no preamble, no process narration.

    ### Finding Verdicts

    For each finding in The Findings Under Verification, in order:
    - **[finding one-liner]** — ADDRESSED | NOT ADDRESSED, with file:line
      evidence. "Attempted" is not addressed: the specific defect must no
      longer exist.

    ### New Breakage in the Fix Diff

    Anything the fix itself broke or introduced, with severity
    (Critical/Important/Minor) and file:line. "None" if clean.

    ### Out-of-Scope Observations

    Issues you noticed entirely outside the fix diff. Non-blocking; the
    controller ledgers these for the final review. "None" if none.

    ### Verdict

    **Fix round:** [All findings addressed, no new Critical/Important
    breakage | Findings remain open] — list the open ones.
```

**Placeholders:**
- `[MODEL]` — REQUIRED: reviewer model per SKILL.md Model Selection; scoped
  re-reviews of small fix diffs take a cheap-to-mid tier
- `/Users/lihongwei/Desktop/晾念头 : Thoughtline/app/.superpowers/sdd/LOCALE-APPEARANCE-PLAN/task-1-brief.md` — the task brief file (same file the implementer worked from)
- `# Task1 fix round1 findings — verbatim reviewer findings

1. **Recompute custom Agent label ink for the new dark paper.** `src/renderer/styles/preferences-theme.css:3` changes dark paper to `#383831`, but `src/renderer/components/ClipCard.tsx:14` still obtains label colors from `src/renderer/components/agentInk.ts:2`, which calculates against the old light gray dark-paper RGB `[179,175,162]`. The applied dark label selector is `src/renderer/styles/overlay.css:88`. A custom Agent with `#4C90D9` gets dark ink `#17416e`, giving **1.1347:1** against the new paper; `#8AADD4` gives **1.1290:1**. This makes the Agent/project line on night-mode rope papers difficult to read and violates the required 4.5:1 contrast. The final appearance test measures only Composer textarea and primary button (`tests/electron/appearance-workflow.cjs:20`), so its passing result does not cover this regression. Update the algorithm/shared palette for the actual light and dark paper colors, allowing lighter ink on dark paper; verify rendered custom Agent labels with representative saturated and neutral colors while preserving the approved clip artwork and user-specified clip color.

2. **Render all Shelf status/error messages through the current locale.** `src/renderer/components/Shelf.tsx:90` outputs `{error||notice}` directly. Several existing handlers still assign Chinese strings, such as the canceled drag at line 66, while the newly translated drag-success messages at lines 58–63 are inside the once-installed event effect ending at line 70 and therefore capture the initial `t`. Reproduction from the code: start an existing Chinese profile, switch to English in Composer/Calendar, then successfully move a rope clip; the completion notice remains Chinese. On an initially English profile, dragging out of bounds still uses the literal Chinese cancellation string. Lower-layer errors have the same bypass. Use the current render-time message boundary or stable message keys/parameters for Shelf notices/errors; do not re-register or cancel live drags merely to change language. Add focused coverage for switch-then-drag completion, cancellation, and a failed page/save operation. The current coverage claim at `acceptance/evidence/appearance/visible-string-coverage.md:14` is broader than the implementation.

3. **Make the error boundary complete and preserve diagnostic bytes instead of matching arbitrary UI templates.** `src/shared/i18n.ts:12` builds reverse regexes for every dictionary template and line 14 applies them to app errors/unknown diagnostics. It has special handling for storage migration and file-mismatch prefixes, but not the actual repository IO shape at `src/main/store/repository.ts:6` (`本地保存未成功，请保留文字并重试。 (${diagnostic})`) or the main storage catch with a suffix (`src/main/index.ts:277`). A focused probe with `本地保存未成功，请保留文字并重试。 (ENOSPC /用户/原始中文)` does not produce the English app message; it remains Chinese with its comma changed. Worse, the generic `dayCount` template matches any Chinese comma, so the diagnostic `ENOENT: open '/用户/原始，中文.json'` becomes `ENOENT: open '/用户/原始, 中文.json'`. This violates both English error coverage and the explicit requirement to preserve diagnostic paths. Prefer typed app errors with separate diagnostic slots, or restrict deliberate reverse mapping to complete known error envelopes and leave their diagnostic payloads untouched. Cover actual repository IO suffixes, startup propagation, the outer main-process storage catch, and diagnostics containing Chinese/ASCII punctuation. The existing nested-storage test (`tests/unit/i18n.test.ts:7`) covers a different prefix and misses this boundary; `acceptance/evidence/appearance/visible-string-coverage.md:16` currently overstates completeness.


## Confirmed cross-task readiness gap

- ⚠️ Cross-task delivery readiness: `scripts/generate-mac-isolated-launcher.cjs:14` still emits `启动${version}隔离体验.command`, while `docs/LOCALE-APPEARANCE-PLAN.md:44` requires `Start-Thoughtline-Isolated-Mac.command` with consistent generator/output names. Resolve this before freezing Task 2 inputs, or explicitly arrange a consistent final asset transformation without claiming an unchanged generator already satisfies it. This is a Task 2 readiness observation, not a fourth Task 1 finding.

Controller resolution: change the active Mac launcher generator to produce ASCII Start-Thoughtline-Isolated-Mac.command consistently before source freezing and both builds; preserve already delivered .2/.16 output files and rollback guide. This is required producer-input readiness, not a fixture-only post-freeze repair. Add covering generator/manifest check without recreating old release assets.

Minor retained/deferred: final validation warning noise accurately labeled; do not rerun full suite solely for cosmetics or enable broad output emptying. Historical missing inventories/out-preflight hash gaps remain explicitly unverified, never retroactively invented. Package/Windows/physical gates belong downstream.
` — the Critical/Important findings and spec gaps from the
  previous review, copied verbatim, one per bullet
- `/Users/lihongwei/Desktop/晾念头 : Thoughtline/app/.superpowers/sdd/LOCALE-APPEARANCE-PLAN/task-1-report.md` — the implementer's report file (fix reports appended)
- `d489b1deed3992fd577da87d390dbc6bddabed3b` — the head the previous review saw
- `7de6eab012bc40ed812115d2f4bebe8f26d65634` — current commit
- `/Users/lihongwei/Desktop/晾念头 : Thoughtline/app/.superpowers/sdd/LOCALE-APPEARANCE-PLAN/task-1-fix-round1-production.diff` — the path `bash scripts/review-package PLAN_FILE FIX_BASE HEAD` printed

**Re-reviewer returns:** per-finding verdicts (ADDRESSED / NOT ADDRESSED),
new breakage in the fix diff, out-of-scope observations, and a round verdict.

Full archived fixdiff: review-d489b1d..7de6eab.diff (526452bytes, mostly raw evidence); focusedproductiondiff47650bytes containsallsource/test/workflow/deliverychanges. Use supplieddiff once; inspect named runlogs/receipts only toverifyclaims. Latest passing11 run is fix-round1/ui-final2, NOT ui-final (retained10pass/1readinessfailure). Full fix report appended at task-1-report.md end. Also verify the fourth confirmed ASCII-generator readiness gap with its actual changedgenerator/test/guide, not only filenamealiases. GlobalConstraints are included verbatim in task1brief. Windows/actualpackage/physicalgates explicitlydownstream; paper remainspaper, candidateglassnotimplemented.
Write full scopedreview to task-1-fix-round1-review.md in thisworkspace (onlyallowedmutation); no other file/index/HEADchanges, no subagents, no broadrevieworElectronlaunches. Return compact per-findingverdict/newbreakage/out-of-scope/reportpath. Useexplicitworkdir andbundledNode24 ifnarrowproberequired; preserve everyfailure.
