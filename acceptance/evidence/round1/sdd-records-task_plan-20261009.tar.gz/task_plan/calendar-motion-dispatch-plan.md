# Calendar motion dispatch plan

## Task 7: hierarchical calendar motion

# 日历日/月/年双向空间缩放（用户追加，最终sourcefreeze前）

工作目录 /Users/lihongwei/Desktop/晾念头 : Thoughtline/app，main。Node24 PATH=/Users/lihongwei/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:/opt/homebrew/bin:/usr/bin:/bin，/bin/sh login:false，显式workdir。先读../AGENTS.md、ui-ux-pro-max SKILL和现有Calendar/auxiliary.css，最新具体要求原话：“归档页面的日历展开缩放的特效 参考苹果手机的日历缩放效果 就是点开日、月、年和返回日、月、年的交互特效 很自然 很舒服”。已先保存/reread项目完整方案，此处是单一具体任务brief。

现状：Calendar月→日纸卡用origin仅120ms scale(.98)淡入，年grid120ms scale(.96)，月返回没有反向空间过渡；这不足满足新增体验。P1-P5数据/原地编辑/日历日期索引与存储已受控实现，不改core；P6版本/CI/工具正准备.17-preview.2，未tag/package。生产源码main最后已提交fa45cb88105db81806e419bba5d8029af9540389，P6工具/test WIP已知归父，不动它们。

## 用户期望与不可变边界
- 日/月/年进入与返回都让人清楚上下层级关系：所点日期格或月份在空间上连续扩展到内容，返回缩回对应格；月份标题进入全年要能看出该月对应的位置，选月份再次展开。导航仍普通单击/返回，不强制捏合、滚轮默认滚动。日纸卡不是iOS时间表，借交互感觉，不挪品牌或冒称原生iOS代码。
- 推荐约200–260ms曲线柔和 ease-out（无反复弹跳）；按实际视觉选合理值，不能用长动画遮卡顿。新操作可打断正在过渡，动画完成不控制业务提交/等待点击；保最新导航，取消旧动画/RAF/timer，卸载清理。减少动态设置立即切换或轻淡入，绝不空间缩放；高对比保文字可读。
- 不改变日期/数量/index/status/search/trash、9+18分页/三列两窄、reader返回scroll、旧日期冻结、主绳只有绳夹纸、统一材质。prepareLeave必须先处理dirtyeditor，未确认composition或失败不离开/不丢文。动画只能显示当前UI，不留全历史DOM或让ghost接收鼠标/键盘。
- 动画需有双向几何/来源记忆而不只是把transformOrigin设中心后微小淡入。可用一个受控overlay/FLIP/WebAnimations helper，避免新增依赖、全屏大截图或过度clone含输入/aria的活DOM。新卡片被点击读写当前window的原地阅读返回也应连续或至少不生硬，保持guard。

## 所有权与验证

只改 Calendar.tsx、auxiliary.css（限calendar）、可新增小renderer hook/纯几何 helper及必要unit/Electroncalendar-motion-workflow.cjs；不改P6scripts/.github/source-input-vector/package-acceptance/inline/storageworkflow，不commit/push/package/tag，不启动真人安装、不碰data/PID30628。不另派reviewer，父独立任务审查后全分支review。

实现前记录现有motion缺口的受控几何/方向RED（不伪装用户设备复现）。测试普通按钮进入年/月/日和返回日→月、月→年、年→月的对应anchor/方向，连续切换打断无残ghost/inert/will-change/animation，取消后最终header/cards/count/IDs和返回scroll稳定；reduced属性不缩放且即时导航，nativefontsize/窄window维持两列。保读写最后修改/失败取消guard，不能改断言去适应坏导航。现有calendar-workflow scoped复跑；相关type/build。仅必要范围，不额外全量或长idle。所有nativefixture串行，故障复位/合成composition结束、最后保存→正常close/quit→PID退出→自有root rm/statENOENT；失败留证不KILL/app.exit，不覆盖旧阶段logs/png。新证据唯一目录 acceptance/evidence/round1/calendar-motion/，attempt子目录或wx；生成序列帧/短视频记录真实source像素和时序方便父检查，不假称iPhone并排/Windows物理验收。

报告 .superpowers/sdd/task_plan/calendar-motion-report.md：方案与取舍、变更、RED/GREEN精确命令/exit、方向/时长/anchor/打断/减少动态/保存/scroll、截图和cleanup实际dir/PID/stat、真实未测（手感待独立QA）。来源：用户描述；Apple Motion HIG https://developer.apple.com/design/human-interface-guidelines/motion 搜索摘要支持让用户跟踪展开过渡/及时反馈；页面正文JS不可读，未声称全文读过或实际iPhone动画一比一复现。整个任务先冻结待父Spec/Quality，不能自行宣称全目标完成。
