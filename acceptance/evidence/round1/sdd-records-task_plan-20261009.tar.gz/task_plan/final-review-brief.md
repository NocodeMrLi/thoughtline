# 第一轮全分支独立审查

本轮基线 main ff39779cbeb562083f3574db4d2998693091b0be，当前 main；只读，不能改代码、提交或启动真人 App。工作目录 /Users/lihongwei/Desktop/晾念头 : Thoughtline/app；Node24 PATH=/Users/lihongwei/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:/opt/homebrew/bin:/usr/bin:/bin，显式 workdir /bin/sh login:false。

读取 ../AGENTS.md、完整用户方案笔记 Thoughtline第一轮修复优化.md、task_plan.md、docs/ROUND1-REPAIR.md、docs/ROUND1-DATA-SAFETY.md、各阶段实施/审查/修复证据（.superpowers/sdd/task_plan 与 acceptance/evidence/round1），核对全变更 git diff baseline...HEAD 和尚未提交生产/测试改动。基线历史验收不当新证据；schema3 旧包回滚限制必须真实。

按 Spec 与 Quality 两轴检查所有11项：项目立即删除完成/退出不恢复且整理undo不能复活；固定主绳/品牌/A4；三意图drag、拆合ID/currentId/order/正文和无效/Esc/undo；外拖协议和明确copy无静默剪贴板/抢焦点/全局粘贴/Enter，真实微信4.1.13.65/QQ豆包/WorkBuddy5.7.6 未测必须标明；即时翻页合并保存、跨窗世代/离开错误/queue互等；全绳空位/new/split/restore/fullnotice；原地四字段CAS/IME/失效会话/关闭隐藏退出/并发save failure；archive/softtrash/独立permanent确认/稳定相邻；辅助窗drag/material/a11y/geometry/DPI逻辑；图标数量/仅group split/更多counts/完整focushover提示；month/day/year/search/status/trash/冻结日期/returnscroll/DOM有界；实际storage/path/open/migration/独立backup/actualrestore/失败回退/configfailclosed/sourcecopy保全。

重点检查跨任务交界：任何组件切卡/标题/层级/窗口路由不能卸载dirtyeditor；Agent拆出和delete广播不丢在途输入；所有snapshot mutate读最新于同queue，prepareLeave/flush不在等待其自己的queue中；结构undo不会覆盖后来内容状态；迁移后旧路径repo引用/过期renderer写入不写旧库/覆写新库。未知schema/config/断盘拒绝空库，原备份精确且不覆盖。最后交付包和源码版本/完整SHA/buildinput/图标来源，旧tag不动，private保持，测试垃圾仅自己清。

优先只读推导与必要限定单测/自己tmp受控复现；不要重复全量/长性能或假Windows物理检查。每项发现具体优先级、文件行、前置/步骤、预期实际、证据、源码推导vs受控。评估未测真机与真实接收端为明确验收门禁，不能用测试textarea/CI判修好或不支持，也不要把环境不可用本身冒认已发生产品缺陷。审查工程可交独立QA范围；任何仍有load-bearing缺陷不能称开发完成。

输出 .superpowers/sdd/task_plan/final-review.md。不得修生产代码；父统一收拢成唯一 final fix wave，再限定复核。请按实际完成状态指出 Critical/Important/Minor，所有deferredminor/parked项也需裁定，不静默丢失发现。

新增用户绑定要求：归档日历参考苹果手机日历自然日/月/年进入和返回缩放；必须读 calendar-motion-report.md、calendar-motion-review.md（任务完成后生成），检查双向实际 anchor/可打断/reduced/scroll/dirtyguard与 bounded DOM，不把原旧120ms淡入当满足。Apple官网仅搜索摘要，未亲见原生iPhone并排。P6任务S1/S2/Q1/Q2修复后限定批准，实际包尚未生成；post-build guard真实运行和最终来源属于后续包门禁，不因此伪造通过。初始和限定review保留在p6-source-review.md。末尾必须逐项列 Declined to judge/暂缓行为及原因，由父裁定，所有minor均需处理或明确保留，禁止新派agent/全量反复跑。

当前Task7 fix1三发现均限定批准，实际组件RED4/GREEN5含resize与返回scroll；S1采用合成manageSession发布，不当真实托盘自然复现。P6 CI已接入7项源Electron回归，名单/独立attempt验证通过，尚无最终Windows runner。最后source-review.diff包含baselineff39779到当前所有生产/构建/测试/契约净差和所有新增输入；完整已提交diff另在final-committed-review.diff，原失败证据按报告索引定向读取，避免误用历史通过数字。

父的额外视觉观察待你独立裁定：acceptance/evidence/round1/calendar-motion/fix1-green-20261009-4/empty-day-return-controlled-early.png（25ms暂停像素）里空状态文字明显横向压缩、纵向拉伸；motion使用scaleX/scaleY分别对齐，日/月/年内容或纸张也可能随不同比例变形。请评估这是否符合用户“自然舒服”的缩放，是否应真实文字/纸卡保持等比并使用空间锚点/容器裁切过渡。此项源像素已视查，但不是自然帧率或真机手感结论；不能因dataset anchor正确而忽略内容视觉，也不要将所有像素瞬间变化当Critical。纳入同一全分支发现列表，父统一最终fix wave。
