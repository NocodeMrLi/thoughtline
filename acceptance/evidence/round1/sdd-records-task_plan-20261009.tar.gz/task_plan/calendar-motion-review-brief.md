# Calendar motion 独立任务审查

只读，不派子 agent，不改 index/源码、不 commit/push。工作目录 /Users/lihongwei/Desktop/晾念头 : Thoughtline/app，Node24 explicit PATH，/bin/sh login:false。先读 calendar-motion-extracted-brief.md（用户原话/绑定要求）、calendar-motion-report.md、calendar-motion-working.diff；仅本次 Calendar/calendar CSS/helper/test 增量，P6 工具文件不扩大审查。源码基线为 fa45cb8 中旧120ms淡入；父提供限定工作差异。

Spec＋Quality 两轴：日月年进入/返回实际对应 anchor 与方向，约200–260ms自然曲线、简短、可打断，减少动态不缩放；month→year/返回不能只是整体scale(.96)；快速多操作保最新导航，无过期 timer/ghost/inert/animation；不阻塞业务、dirty/IME prepareLeave；保当前 IDs/counts、日期索引、9+18分页、窄窗两列、reader返回scroll，空日与status/search/trash正常。视觉必须由真实sourceframe产生，不能声称亲见iPhone或物理Windows。审查几何过渡是否有明显硬切，或只缩目标小格而丢失父层级关系；勿因单测存在直接批准。

父视查第一版发现仅空矩形边框在标题和月份格之间移动，真实年月日内容仍全尺寸淡入，要求实现者在自检中修正并保留原attempt。明确语义：标题按钮只是入口，month-grid可见内容缩到year中对应月份格，反向该格展开为month-grid；date-cell展开为日纸卡可见内容，返回内容缩回对应日期格。真实有界内容必须参与视觉缩放，不能仅验dataset几何代理。可用不可交互的小视觉副本或目标FLIP，避免复制整段历史／活输入。减少动态必须取消活动缩放，而非仅在下次导航时跳过。

实现者初次冻结报告指出旧 calendar-geometry-workflow 仍依赖120ms/transformOrigin；父明确授权原实现者追加必要测试整合，保所有bounds记忆/Detail不污染/数据断言，更新为空间方向与anchor新契约，单独回归后再次冻结。审查须含这一增量。检查异步navigationIntent是否同时失效于manageSession切换/卸载，旧prepareLeave回调不能在新会话改层级或选择；这只是待审查交界线索，尚无独立复现结论。

优先读源码、覆盖测试和 raw attempt 证据，必要只做限定 unit 或自己 tmp 受控复现；不重复全量/type/build/长 native fixture，除非具体新问题需证实。所有报告 actual host，Windows物理未测不认作已发生的开发缺陷；自身新fixture若有必须正常flush/quit/PID/stat自清。报告 .superpowers/sdd/task_plan/calendar-motion-review.md，具体优先级、文件行、步骤、预期实际、源码推导vs受控。没有发现也给明确Spec/Quality批准与未测边界；发现则父返回原implementer修复。
