# P3/P4 集成独立审查

只读审查，不改生产代码、不 commit/push、不操作真人数据或已有进程。工作目录 /Users/lihongwei/Desktop/晾念头 : Thoughtline/app，HEAD e4bb97c75c87a032ba1a8052d5a22b35e1cb806d；当前数据与 UI 未提交。Node24 PATH=/Users/lihongwei/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:/opt/homebrew/bin:/usr/bin:/bin；显式 workdir，/bin/sh login:false。

先读 ../AGENTS.md、task_plan.md、p3-ui-brief.md、p3-ui-report.md、p3-data-review.md 与 docs/ROUND1-REPAIR.md。用户本轮新规格优先旧取消编辑和绳下沉规则。主界面只有绳/夹/纸，项目删除立即且退出不恢复。技能要求 Spec 和 Quality 两轴审查。

检查当前实际 git diff 和所有未跟踪生产文件，不能只读 diff 漏新文件。数据层已独立审查通过，仅纳入集成边界，不重复全范围数据审查。重点：

- 原地编辑四字段 CAS、350ms 保存、中文 composition 候选不最终持久化、切卡/翻页/OS close/hide/quit 最后 flush 失败保本地文字/窗口，不假成功，过期 session/旧 cleanup 不关闭新 owner；新建窗只有新建。
- 所有 snapshot 修改在同一个 mutation queue 中执行时取最新值和 revision，prepareViews 必须在队列外，检查 P2 页码与编辑/删除/设置互等和旧内容覆盖。
- 最近删除/恢复/永久确认、当前同夹邻项、结构 undo 不复活项目删除/内容编辑/softdelete，正文/ID/创建日/顺序安全。
- 日历默认本月今天、日3列9+更多窄2列、年12个月数量、范围按日期段、搜索状态/Agent/最近删除、返回滚动和已加载数量；DOM 有界，frozen createdDay（archive计入/trash排除）；跨午夜/时区仅今天更新、历史不漂移。
- 窗口 drag/no-drag、可调大小/几何保存/移除副屏逻辑、材质按 nativeTheme/降低透明度/高对比降级，不能冒称 Liquid Glass，真实物理测试保持未测。图标 hover/focus 完整提示，更多影响数量准确。
- 新旧测试内容保护断言仍在；失败记录保留；测试环境实际隔离，cleanup 不是空口 true。Windows 预检 schema2 exact comparison 的迁移已交后续任务，列转移项不能冒称此阶段 Windows 通过。

必要时只运行有限相关单测/typecheck或自己的独立 tmp 合成复现（fakeclipboard），不重复已通过全量/长 idle。不能操作他人的测试进程。每项发现记录优先级、精确文件/行、触发步骤、预期/实际及证据；区分源码推导、受控复现、未测真机。输出 .superpowers/sdd/task_plan/p3-ui-review.md，有发现也不要修，父统一派实现修复。审查最终需两轴结论与所有仍开放门禁。
