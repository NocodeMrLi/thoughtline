# P3 / P4 原地编辑、日历、窗口集成

工作目录 /Users/lihongwei/Desktop/晾念头 : Thoughtline/app，branch main；P2 baseline 97875dda8d85201ff088218a347f7de2c301dc7e 已推送。下一 implementer 使用 Node24 PATH=/Users/lihongwei/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:/opt/homebrew/bin:/usr/bin:/bin、/bin/sh login:false、显式 workdir。先读 ../AGENTS.md、task_plan.md、最新 docs/ROUND1-REPAIR.md、数据任务报告。用户明确当前新规格优先旧 09 实施计划与 AGENTS 里的数量下沉；固定绳形、A4纸、主界面永远绳/夹/纸。不要换图标、安装版、真实数据、系统偏好、安全设置。不要 commit/push；父统一阶段提交。

拥有 src/main/index.ts、src/main/windows/manage.ts、新窗口 geometry shared helper及对应 unit、src/shared/bridge.ts、src/preload/index.ts、src/renderer（必要 components/hooks/styles）与 tests/electron 内受影响工作流（保持内容保护断言，不删除失败）。不能改 src/shared/contracts.ts/ideaCommands.ts/ideaHistory.ts 或 repository.ts 除非报告确切底层缺口，父另安排。数据任务先完成才开始你任务。renderer 中未跟踪组件 InlineIdeaEditor/ActionIcon/IdeaReader/Calendar/AgentSettings 和 auxiliary.css 是初稿，未接入、未验证；你必须审查完善后接入。现有 inline-edit-workflow/calendar-workflow 在旧UI失败的 RED logs/cleanup 已保存，不能删。可优化不合理 fixture 等待，必须解释且保留语义断言。

## 保存与 IPC
- bridge 正式 typed updateIdea(id,draft,expectedDraft,manageSession)、setEditing(active,manageSession)、ideaHistory(id,delete|restore|permanent,revision)，PilotInfo manageMaterial、manageEditingRequested（可选起始编辑标志，稳定 session）、actual viewport 使用旧 info.width。
- updateIdea 管理窗口可信主frame/会话检查入口与执行时都核对，串行 composerWrite 在执行时对四个内容字段做 editIdeaIfUnchanged。无关页码/设置变更不冲突，原记录并发修改返回 CONFLICT；迟到 session 拒绝。validated text最多1MiB；保 ID/date/status。更改Agent的合夹拆出须显式确认 UI。
- status/agent/clip/settings/history 等 snapshot mutation 执行时必须同一队列读取最新 snapshot，revision检查在队列内部；禁止计算旧 next 后等待页码/其他编辑，避免覆盖。prepareViews 必须在进入该队列前等待，绝不可队列内等待另一个 flush 也要队列。P2 submit满位先释放队列再开Detail已修，保留。
- 源组件 InlineIdeaEditor 用 DraftAutosaver350/1500 与 CompositionSession，IME组合暂停，候选不最终保存，切卡/翻页/关闭/退出先 guard；失败保留窗口和可恢复本地文字，status不得假成功；恢复后显式重试。old session / oldnode /旧ack不能覆盖最新内容。卸载仅在所有 guard 已通过；native close/hide 的未保存editor不能销毁/遗弃：OS close先preventDefault再 async prepareWindow，失败保窗口；guard前不要focus/blur结束选字。manageEditing跟 session 关联，onhide有dirty时应安全flush，失败恢复可见并提示；不要 timed destroy failed/active editor。主进程保存成功才 release。正常close/hide后30s释放可继续。
- 新建Composer只新建。openEdit旧API路由到已有Manage Detail原地编辑；不再打开Composer，任何产品编辑路径都在原窗。用户已授权改变旧取消编辑语义为autosave；更新对应旧tests为在原窗完成/close flush/IME保护，正文/元数据保护断言保留，旧日志不删。

## Reader/Detail
- 同一IdeaReader展示readonly全文或原地编辑 title/body/project/Agent；toolbar轻量 icon copy/edit/archive/split仅group/more，更多 splitAll/archiveAll 标几张 + softdelete1。softdelete进入trash可恢复，permanent单独明确确认且仅deleted。copy显式触发，失败不偷偷clipboard。
- 顶部日历icon进入历史（aria label 念头日历）；undo只有canUndo true显示弯箭头。hover/focus tooltip完整在可见范围，主窗不开toolbar。
- Detail保heldclip/useClipPage，页码即时后台保存；select/flip先 prepareLeave处理editor，如只阅读不用串行大延迟；连续click同步累积不能捕获旧index、吞操作。标题列表/键盘left/right保持。删除当前条选择同夹相邻，单条deleted显示明确已移recentdelete或稳定空态，不跳不相关条；clip消失不渲染错误旧页。
- split/splitAll/restore用P2空间分配/保旧位置，满位notice入口日历。结构undo不能恢复softdelete/项目删除。更新了内容应清理或重基undo不覆写编辑。

## Calendar
- Manage替换为Calendar；AgentSettings复用抽出版本删除duplication。默认本月今天高亮，有记录日期miniClip+数量，无记录只日期；单click日期轻scale从该格展开（可用transformOrigin点击格到卡片区域或简短 origin过渡），默认9卡3列+更多18+正常滚动，窄窗口2列。date index按共享 frozen createdDay；archive计入，deleted不计。大量历史分页，不一次全DOM。
- 月标题缩到年12个月，各month数量+有内容clip；查看本月/全年按日期段卡片。year前后、month前后/今天。搜索全文/名称/项目/Agent和状态小filter，trash次级；所有导航普通单击，wheel滚动。动画120ms可中断/reducedMotion无位移，无无限摇。
- 原窗reader编辑→返回恢复day/level/limit/scroll（真实在click瞬间的scroll，不是click导致浏览器自动滚之前的错误预设），返回month/year位置；快速切卡guard。搜索/状态切换resetlimit与scroll=0。今天随跨午夜/时区变化刷新，历史createdDay不重算（timer/focus合理lowfrequency，清理）；空日期正确。
- calendarMonth/day/year counts与calendar-workflow test全部保留。支持更多范围、空日期、窄2列、大量history只有限DOM、永久delete确认、stable相邻selection等 meaningful assertions。

## Windows/material/geometry
- createManage resizable true minWidth350/minHeight360，与createComposer一致 currentComposerMaterial native vibrancy/mac、acrylicwin supported、opaque accessibility fallback；type data-material/data-platform准确随focus/nativeTheme，不宣称Liquid Glass。不用系统偏好变更。
- header干净 drag，按钮/input/select/nav/textarea/card/no-drag；CSS引用 auxiliary.css。三类fonts/radius/spacing协调正文纸承托。Settings材质也接同data attrs、旧提示挂绳下沉改为固定绳形。
- Calendar bounds可选settings.calendarBounds已由data任务实现；持久化debouncedmove/resize时保全部setting fields不覆盖其他data，打开calendar恢复位置/大小，Detail/Settings不写calendarbounds。programmaticsetbounds路由设mode后防污染，使用restore/route flag或只userresize后persist。display removed/metrics clamp所有manage位置可见。纯clamp helper测试negativeorigin/secondarydisconnect/oversized/125%/150% scaledworkAreas；这是逻辑模拟，不称物理多屏。
- Settings save保留calendarBounds，不能重建字段丢几何。Details edit需要足够高度/scroll，窗口按钮不冲突。

## 测试 / evidence / 输出
先跑覆盖 typecheck/build和unit，再独立fake clipboard Electron inline/calendar，P2 page-handoff all/status/queue、paper/overflow/group/project/text-drag affected回归。不要为通过删除断言或隐藏失败。旧 workflow/group/package/edit tests按新UI语义调整，完整正文/ID/Agent拆出保护必须保留；run相关本地可行测试，不宣称真IME/Win/DPI/真实receiver通过。失败留对应 attempt名。所有 fixtures tmp合成且测试前确认 profile/dir；finally异常若guard阻止退出，先复原注入fault/正常flush，必要 app.exit只自有fixture并记录异常，不全局pkill。cleanup receipt具体dirs/pids必须真实核实，不只写true。
报告 .superpowers/sdd/task_plan/p3-ui-report.md，完整范围/源码推导vs受控结果、退出码、失败与剩余限制、测试变更理由。evidence acceptance/evidence/round1/p3-ui-*.log、screenshots等。不提交，父派 spec+quality independent review。P5 storage另任务，本次Settings可留存储行待接入但不得假按钮。不要停在初稿，仅报告通过确已跑的证据。

集成细节补充：setEditing(active,session)可增加 ideaId owner 参数，main inactive只能清自己的owner，防止同一calendar session切卡时旧cleanup关闭新editor保护；旧session全部忽略。calendarIndex(snapshot,filters)返回 Map<string,Idea[]>、ideaDay(idea) frozen日字符串，默认archive included/deleted excluded，数据agent已确认。保留今天跨午夜lowfrequency刷新清理。InlineIdeaEditor本地draft不能因无关snapshot广播自动reset；真正并发同内容冲突保持draft并提示。UI初稿标题/正文/项目CompositionSession必须原本owner保护。
