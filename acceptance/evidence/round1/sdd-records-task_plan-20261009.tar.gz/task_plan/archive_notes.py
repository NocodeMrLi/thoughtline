from pathlib import Path
import os,re,json,hashlib,urllib.parse
root=Path('/Users/lihongwei/安安的成长笔记📒/晾念头 Thoughtline')
archive=root/'归档'; archive.mkdir(exist_ok=True)
assert not (archive/'20261009-归档清单.json').exists(), '已有清单，停止避免覆盖'
nums={6,10,*range(14,26),*range(27,34)}
moves={}
for f in root.glob('*.md'):
 if f.name[:2].isdigit() and int(f.name[:2]) in nums: moves[f]=archive/'阶段记录'/f.name
for d in ['历史版本','原始交付']:
 if (root/d).exists(): moves[root/d]=archive/d
for old,new in moves.items(): assert not new.exists(),str(new)
originals={f:f.read_bytes() for f in root.rglob('*') if f.is_file() and archive not in f.parents}
def remap(p):
 for a,b in moves.items():
  if p==a or a in p.parents: return b/p.relative_to(a)
 return p
mds={f:data.decode('utf-8') for f,data in originals.items() if f.suffix=='.md' and '证据' not in f.parts and '历史版本' not in f.parts and '原始交付' not in f.parts}
link=re.compile(r'(?P<lead>!?\[[^\]\n]*\]\()(?P<target><[^>\n]+>|[^)\n]+)(?P<end>\))')
updates={}; counts={}; introduced=[]
for old,s in mds.items():
 new=remap(old); count=[0]
 def replace(m):
  target=m['target'];angled=target.startswith('<') and target.endswith('>'); raw=target[1:-1] if angled else target
  if re.match(r'^[A-Za-z][A-Za-z0-9+.-]*:',raw) or raw.startswith('#'): return m[0]
  path,sep,fragment=raw.partition('#'); decoded=urllib.parse.unquote(path)
  if not decoded:return m[0]
  resolved=Path(decoded) if decoded.startswith('/') else Path(os.path.abspath(old.parent/decoded))
  mapped=remap(resolved)
  if resolved.exists() and not mapped.exists() and mapped==resolved: introduced.append(str(mapped))
  updated=str(mapped) if decoded.startswith('/') else os.path.relpath(mapped,new.parent)
  if updated==decoded:return m[0]
  count[0]+=1;final=updated+(sep+fragment if sep else '')
  if angled or ' ' in final:final='<'+final+'>'
  return m['lead']+final+m['end']
 out=link.sub(replace,s)
 if out!=s: updates[old]=out.encode(); counts[str(old.relative_to(root))]=count[0]
# Prefix current entry only; retain the complete user-authored historical body.
for name,title in [('00-阅读与执行入口.md','当前执行入口'),('07-开工进度与测试包.md','当前进度入口')]:
 f=root/name;s=updates.get(f,originals[f]).decode()
 prefix=f'> **{title}（2026-10-09）：** 本轮以 [[Thoughtline第一轮修复优化]] 为准，P1 已提交，P2 已完成限定复核、待阶段提交；P3–P5 待实施。已发布版本仍为 v0.0.16-preview.6。下列较早版本与“当前”表述保留为历史时间线，请勿视作本轮完成状态。历史阶段记录及原始交付集中在 [[归档/归档索引]]。\n\n'
 updates[f]=(prefix+s).encode()
# Save exact originals before any link/prefix change; no evidence bytes are altered.
backup=archive/'整理前原件-20261009'
for f in updates:
 dest=backup/f.relative_to(root);dest.parent.mkdir(parents=True,exist_ok=True)
 with dest.open('xb') as h:h.write(originals[f])
for old,new in moves.items():new.parent.mkdir(parents=True,exist_ok=True);old.rename(new)
for old,data in updates.items():
 f=remap(old)
 assert f.read_bytes()==originals[old],f'并发修改 {f}'
 f.write_bytes(data)
rows=[]
for old,data in originals.items():
 new=remap(old)
 if new!=old or old in updates:
  actual=new.read_bytes();expected=updates.get(old,data)
  assert actual==expected,str(new)
  rows.append({'old':str(old.relative_to(root)),'new':str(new.relative_to(root)),'sha256Before':hashlib.sha256(data).hexdigest(),'sha256After':hashlib.sha256(actual).hexdigest(),'bytesBefore':len(data),'bytesAfter':len(actual),'exactOriginal':str((backup/old.relative_to(root)).relative_to(root)) if old in updates else str(new.relative_to(root))})
manifest={'date':'2026-10-09','reason':'用户授权集中历史阶段归档；活跃设计、完整方案、正式图标、最新交付保留','movedTopLevelNotes':sum(p.is_file() for p in moves.values()),'movedDirectories':[str(p.relative_to(root)) for p in moves.values() if p.is_dir()],'linkRewrites':counts,'files':rows,'evidenceUntouched':True,'newBrokenMovedTargets':introduced}
(archive/'20261009-归档清单.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
index='# 归档索引\n\n2026-10-09 按用户要求集中归档。此处为历史记录，状态与包入口以当时日期为准；当前实施以 [[../Thoughtline第一轮修复优化]]、[[../00-阅读与执行入口]]、[[../07-开工进度与测试包]] 为准。\n\n## 阶段记录\n\n'
for f in sorted((archive/'阶段记录').glob('*.md')):index+=f'- [[阶段记录/{f.stem}]]\n'
index+='\n## 原始副本与校验\n\n- 历史版本：`历史版本/`，完整移动，文件字节保留。\n- 原始交付：`原始交付/`，完整移动，文件字节保留。\n- 链接修正与入口提示前的精确原件：`整理前原件-20261009/`。\n- 移动路径、修改前后 SHA256 和字节数：`20261009-归档清单.json`。\n- `证据/`、截图、当前方案、生产资源均保留；历史证据内的旧路径文字不修改，不把历史链接当新验收证据。\n'
(archive/'归档索引.md').write_text(index)
# Verify every moved file and retained raw evidence against original bytes.
for f,data in originals.items():
 if '证据' in f.parts:assert f.read_bytes()==data
 assert remap(f).is_file()
print(json.dumps({'topLevelArchived':manifest['movedTopLevelNotes'],'filesVerified':len(rows),'rewrittenNotes':len(updates),'evidenceByteUnchanged':True,'manifest':str(archive/'20261009-归档清单.json'),'title':(archive/'归档索引.md').read_text().splitlines()[0]},ensure_ascii=False))
