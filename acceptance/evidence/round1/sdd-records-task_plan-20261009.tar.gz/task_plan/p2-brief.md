# P2检查要求
审查当前未提交P2实现；基线main1d8705d8e6b2a4283bd253aa86e1b1cbf7a37e00。
绳主界面只有绳夹纸；木夹整夹、上缘留白当前单张、正文标准text/plain外拖copy保留原文。合法预览、松手执行、无效/Esc不变；兼容Agent才能合并，反复拆合ID顺序当前页正文保存。布局所有左右中间空位搜索，新建/拆出/恢复冻结旧手动位置；真满辅助窗口告知+查看。分页即时，连续点击不吞，100ms合并/300ms上限后台持久化，旧请求不覆盖、失败可重试、离开前flush。Windows launcher严格新版本0.0.17-preview.1，不替换旧发布。微信/豆包/WorkBuddy真实接收独立未测，用户反馈版本4.1.13.65/QQ未知/5.7.6；不能宣称兼容修好。
相关证据115单测passed4Winonlyskip，p2-group/text-drag/paper-native/page-timing日志；受控测试不等于系统物理验收。审查并报告spec compliance及quality，Critical/Important/Minor与准确行号、真实机制。不修改源码，不运行全量测试，不commit。报告写p2-review.md，简短返回结论。
