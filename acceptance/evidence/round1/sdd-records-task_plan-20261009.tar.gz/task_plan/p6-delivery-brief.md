# P6 冻结验证与双端独立测试包

在 P3/P4/P5 功能、受影响回归与独立审查完成后执行；本文件仅计划，未实施。main，用户已授权阶段提交/push与私有测试预发布，不需要再询问发布。严禁公开仓库、覆盖 v0.0.16-preview.6/tag、替换用户安装、真实数据、安全偏好或他人工作树。

最终候选建议 0.0.17-preview.2（preview.1 是前面阶段 CI 开发包，没有发布tag），package/lock/version-bound launcher/preflight isolationdir 都一致，旧 preview.1 launcher在docs/delivery/archive保留，不放宽版本校验。首先核实tag/release不存在，源生产/测试输入与包清单绑定精确冻结SHA。需要修复则新commit并重建受影响包，不能假称旧包最新source。

## 验证
- 全量 verify只需对最终改动完成一次，相关unit+source Electron回归覆盖分组/drag/space/page/inline/IME/trash/calendar/geometry/storage/restore；无关旧历史性能不继承为fresh。截图须真实新UI，受控与物理分开。
- .github/workflows/test-packages.yml 增加独立 Windows runner source runtime UI tests（fakeclipboard/emulated shortcuts）：至少 inline/calendar/storage 与新建 CtrlEnter/Enter/229真实Electron事件（不是纯unit）。fixture用process.platform/真实OS版本返回metadata，不能硬写Macscope导致Win证据冒名。可在CI跑3个主要integrationtests，保留logs/cleanup/screenshots作为artifact，无业务测试放宽；首次CI失败要保存日志。Windows源DOM/IPC也不是物理IME/DPI/焦点/多屏/receiver。
- 已有Windows installed/installer preflight验证strictversion/default profile/singleinstance/NSIS install/reinstall/uninstall data preservation，schema预期改3保其它内容保护断言。ASAR编译/assets/批准图标PE一致，来源headSha。签名NotSigned事实不变。
- 类型/单测/构建和审查后controller提交sourcefreeze及push触发一次CI，不另重复dispatch。最终headSha/run status与artifact核对，下载到最终deliverydir，EXE/version/arch/manifest/hash/inputvector都核对；ZIP digest和installerhash分别记录，不混淆。sourceCI构建能通过但物理Windows欄未测。

## Mac
正式 script package-mac，若外部Electron下载阻挡，先保留失败，核现有Electron44.7.0缓存所有文件与node_modules/electron/dist逐字节一致，然后用builder原生 electronDist config离线参数重建（不改生产依赖、不伪manifest）。strict codesign BuiltApp+只读DMG内App均校验，ad-hoc不DeveloperID/公证。不关闭Gatekeeper/去隔离。
盘内App冻结实际acceptance launch THOUGHTLINE_DATA_DIR tmp、源/编译out/assets逐hash、app.asar绑定；正文首尾空白/emoji/原地编辑closeflush/restart/newDraft未被编辑覆盖/calendarsnapshot/softdelete/storageactualrestore必要受影响包检查。旧package-acceptance已由UI阶段改新autosave语义，保全文IDmetadata保护。清理自有PID/fixture、detachDMG/空mount，仅自建构建副本可清，最终DMG/EXE/manifest/证据/旧回滚包保留。

## 来源和私有预发布
冻结main SHA后pack，确定tag/release SHA（可以后续docs/evidencecommit作为tag但全部production/build/testing输入与Mac/Win实际buildsource逐mode/blob比较）。包含src/assets/scripts/tests/package/lock/licenses/THIRD_PARTY/tsconfig/electron.vite/.github/.gitattributes/.gitignore和version-bound交付入口。比较不能只版本或out几文件；manifest明确actualMacBuildSource/actualWinBuildSource/releaseCommit。
仓库private live核实，创建draft private prerelease tag v0.0.17-preview.2（没有复用旧tag），上传新双端包+SHA256SUMS+两端buildmanifest+release manifest+隔离launcher，size/digest服务端准确比对后可publish仍prerelease。禁止 --clobber旧资产、公开仓库、自动更新、自动安装。若签名/网络/权限受阻准确报告范围，不为了发布放松。

## 文档 / 最终报告
同步README/gates（historical fields明确历史）/docs ROUND1-REPAIR/新的 release notes/独立QA清单，项目笔记方案分方案/实现状态/测试证据/剩余问题；准确mainSHA/status/trees、每要求11项状态、包版本/架构/路径/SHA/buildsource、已测范围与具体未测、migration原rawbackup/data-location/独立backupactualrestore/旧schema3 rollback限制、必要证据/垃圾清理与遗留。不要写用户验收通过。Mac/Win physical/Wechat4.1.13.65/DoubaoQQunknown/WorkBuddy5.7.6仍需真实接收矩阵，不因sourceprotocol或CI判unsupported/fixed。开发完成交由用户另一轮独立QA，报告优先级/复现/预期实际/证据格式在 acceptance/ROUND1-INDEPENDENT-QA.md。

controller还须broad whole-branch review（most capable available）与必要fix复审后才标开发完成。技能scratch报告复制tracked证据避免compaction丢失，用户要求retainfailure/provenance优先于清scratch；不删除旧branch/G7/worktree，不reset/rewrite/forcepush。

## 控制与交付目录补充

交付目录用 /Users/lihongwei/Documents/Codex/2026-10-09/thoughtline-round1-repair/delivery/v0.0.17-preview.2（若已存在先核对，不覆盖不同来源）。不把新包塞入旧 preview6 发布目录，不移动旧回滚包。Mac也提供严格版本绑定的隔离启动入口；可复用旧 .15 launcher 的可靠结构，但不能用旧版本常量，不能 xattr 去隔离、关闭 Gatekeeper 或自动安装。旧 .15入口保留。新入口/Windows入口都在源冻结前完成，构建输入向量纳入 docs/delivery。

你不 commit/push。先完成版本/CI/launcher/必要测试接入并告知生产与构建输入已冻结，父做全分支独立审查和必要 fix wave，父提交/push，给你准确源码 SHA 与 Windows run，之后再实际构建、下载、包测试和私有测试预发布准备。不要提前发布或给错误 commit 打 tag；父对范围和来源核验后授权最后发布即可，现有用户授权已覆盖私有测试预发布，不再向用户重复确认。

Mac暂时外网下载失败时保留失败证据，并通过 builder 的原生 electronDist 配置使用全量 byte 比对后的现有缓存。不要改 package-mac 以放松签名；可以增加受控环境输入/CLI参数让既有严格脚本走可信本地分发路径，相关输入也必须冻结在生产/构建向量中。

用户最新强调清理测试垃圾、减电脑负担并避免程序异常退出。fixture 恢复故障注入、保存、正常 close/quit、确认自己PID退出，再删自己tmpdir；app.exit/KILL不是常规通过。异常退出/关闭挂起留失败证据先定位。最终 delivery 校验后，可清本轮自建下载ZIP、重复包、打包中间App副本和已detach的临时mount目录，保留最终双端包/清单/截图/日志/回滚点；不得删已有依赖缓存、旧发布、用户安装或他人任务。每项清理写目录/归属/校验/PID/stat结果，资源占用只给实际可查事实，不假称性能改善。

## 当前源码核对修正

2026-10-09 父静态回读 tests/electron/package-acceptance.cjs 确认仍是旧 Composer edit/cancel/save 语义（openEdit 后查询 #idea-text、取消编辑并关闭、保存修改）。上述旧“已由 UI 阶段改”句不是实际当前事实。P6必须将冻结App验收改为新 Detail/calendar 原地自动保存、正常close flush/restart、完整ID/metadata/draft保护；保旧失败证据，不跳过本项。

## Mac 启动入口哈希与源码冻结的先后关系

冻结仓库内生成器或模板（纳入 scripts/docs/delivery 输入向量），在 actualDMG/asar hash确定后仅向 finaldeliverydir 生成含确切版本、DMG/asar哈希的可执行.command；不再修改仓库内冻结模板或生产输入。记录模板/生成器 Git对象及最终入口SHA，可重新生成比对。tag指向实际冻结源码commit，后续报告/evidence-only提交不改变tag。这样避免为了填入尚未产生的DMG哈希而改变被声称相同的构建来源。Windows严格版本launcher仍纳入冻结仓库。Mac final.command 不能接受任意用户传入hash、fallback安装版或去隔离。

父只读核验已完成：acceptance/evidence/round1/p6-electron-cache-binding.json 对 Electron44.7.0 arm64 cacheZip 的273个文件/符号链接逐字节或目标比对 node_modules/electron/dist，0 mismatch。CacheZip真实路径 /Users/lihongwei/Library/Caches/electron/5a625dfd3df3efc3971556afe64989f9aa6ea0f4cd6e33889c1951789041498f/electron-v44.7.0-darwin-arm64.zip。可引用此完整比对并再核version/identity，不必重复大文件扫描；现有cache和deps不清理。若直接用可信本地electronDist重建以避免冗余网络/下载负担，记录这个选择，不伪造本轮下载失败。
