import datetime
import json
import os
import pathlib

root = pathlib.Path('acceptance/evidence/round1')
receipts = []
errors = []
missing_directory = []

def inspect(value, file, pointer=''):
    if isinstance(value, dict):
        ids = value.get('pids', value.get('ownedPids'))
        if isinstance(ids, list) and ids and all(isinstance(pid, int) for pid in ids):
            directory = value.get('directory', value.get('dir', value.get('fixtureDataDir', value.get('dataDir', value.get('root')))))
            if not isinstance(directory, str):
                missing_directory.append({'file': str(file), 'pointer': pointer, 'pids': ids})
            elif directory.startswith(('/var/folders/', '/private/var/folders/', '/tmp/', '/private/tmp/')):
                states = []
                for pid in sorted(set(ids)):
                    try:
                        os.kill(pid, 0)
                        state = 'alive_or_reused'
                    except ProcessLookupError:
                        state = 'ESRCH'
                    except PermissionError:
                        state = 'EPERM'
                    states.append({'pid': pid, 'state': state})
                try:
                    os.stat(directory)
                    stat = 'exists'
                except FileNotFoundError:
                    stat = 'ENOENT'
                receipts.append({'file': str(file), 'pointer': pointer, 'directory': directory,
                                 'stat': stat, 'pids': states, 'normalClose': value.get('normalClose')})
        for key, child in value.items():
            inspect(child, file, pointer + '/' + str(key))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            inspect(child, file, pointer + '/' + str(index))

for file in sorted(root.rglob('*.json')):
    if file.name in ['controller-final-cleanup-audit.json']:
        continue
    try:
        inspect(json.loads(file.read_text()), file)
    except Exception as error:
        errors.append({'file': str(file), 'error': str(error)})

report = {
    'at': datetime.datetime.now().astimezone().isoformat(),
    'scope': 'Read-only stat and PID-0 audit of recorded Mac temporary fixture receipts. No deletion or signal; Windows paths excluded. Historical receipts without directory cannot be independently stat-checked. Live PID may be reused and is never killed.',
    'receipts': receipts,
    'recordedPidsWithoutDirectory': missing_directory,
    'unreadableJson': errors,
    'recordedTemporaryDirectoriesAbsent': all(item['stat'] == 'ENOENT' for item in receipts),
    'recordedPidsAbsent': all(pid['state'] == 'ESRCH' for item in receipts for pid in item['pids']),
}
output = root / 'controller-final-cleanup-audit.json'
output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'receiptCount': len(receipts),
                  'uniquePids': len({pid['pid'] for item in receipts for pid in item['pids']}),
                  'allTemporaryDirectoriesAbsent': report['recordedTemporaryDirectoriesAbsent'],
                  'allRecordedPidsAbsent': report['recordedPidsAbsent'],
                  'unreadableJson': len(errors), 'historicalWithoutDirectory': len(missing_directory)}))
