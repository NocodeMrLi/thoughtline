# P5 存储位置、迁移、独立备份和实际恢复

在 P3/P4 窗口阶段完成之后执行；用户完整方案 Thoughtline第一轮修复优化.md 第11项和验收数据保护为最高优先级。main 开发，不commit/push，不公开仓库或替换安装。Node24 PATH/明确workdir/bin/sh login:false；only独立tmpdir合成数据、fakeclipboard。先读 ../AGENTS.md、docs/ROUND1-REPAIR.md、最新 p3-data / p3-ui 报告、TDD技能。

拥有：新 src/main/store/storageLocations.ts 及相关 unit tests；src/main/index.ts（只存储初始化/IPC相关）、bridge/preload、Settings.tsx和存储相关CSS、tests/electron/storage-workflow.cjs 与必要 package/newsettings测试。不要重构其他功能，不改 migration date/trash/editor核心。除发现明确缺口外不修改 repository.ts / ideaCommands.ts。报告 .superpowers/sdd/task_plan/p5-storage-report.md，不提交，父派独立审查。

## 数据边界
Electron userData profile仍由 THOUGHTLINE_DATA_DIR 或系统目录决定，Chrome cache/锁/快捷键配置profile保持，念头数据可以独立目录。data-location.json 存在profile且原子写入，仅包含schema/path等必要元信息，无secret。UI明确显示“念头数据位置”实际绝对路径（不是假示例），并说明缓存所在profile仍独立。main repository/dataDir从const改let，入口成功才能switch。configured dir丢失、权限错误、disk断开/manifest不合法必须failclosed恢复提示，不调用FileRepository新建空库。无config首次正常启动才默认profile，若config有指向但snapshot/bak均缺失则绝不空库。unknownconfigversion不覆盖。startup retry/folder/exit按真实问题处理，不假loadsuccess。目录选择原生dialog只在用户按钮点击时触发；不抢前台应用焦点，不新增权限。

## 可测纯模块API（你可细化签名）
- loadStorageDirectory(profileDir):Result<string>，configured有效存在有可读合法snapshot或bak，profilemissingconfig用default；非法config/访问失效返回明确IO/INVALID，原内容保持。
- migrateStorage(source,target,expectedSnapshot,commitLocation, io?) :Result<verifiedtarget>；调用方先prepareViews/flush pending在进入mutationqueue前（防互等），在queue内repository.flush后基于最新snapshot。当前数据如仍旧schema1/2，首次写schema3前保全exactlegacybackup，必要commit一次不改内容但正确schema。迁移只复制独立owned数据文件（snapshot.json/snapshot.bak.json/schema1/2backup/corrupt recovery），不搬Chrome缓存、不迁移test entry、不删原副本。
- source与target不是同realpath，目录及文件避免symlink/traversal；target选已存在空目录（如要创建仅自己新建可rollback），有未知文件/已存在数据拒绝，不mergeoverwrite。copyfile COPYFILE_EXCL，完整bytehash/size逐项校验，validateSnapshot与期望数据/revision完整一致，fsync文件（有可行dirflush也做）。确认成功且无缺失才atomic commitLocation(profile data-location.json)；main再换repository、snapshot及dataDir（不要config已写但后续Load失败无法回退：模块应先准备/验证repo并返回，或rollbackconfig）。失败仍使用旧repo/旧config，原sourcebyteunchanged；清理只本次创建且hash能验证归属的files，保留用户已有目标文件和oldcopy，错误报告明确。
- exportBackup(source,parent,expectedSnapshot,appVersion):Result<backupPath>，独立时间UUID子目录，manifest记录schema/appversion/revision/time及filename SHA256/size；currentlocation配置绝不变化，backup不等于migration。export和migrate都拒绝不一致cached/source snapshot；备份可以含oldschemaexactfallback，但manifest要一致且raw可实际恢复。
- restoreBackup(backup,target,...):先验证所有manifest/ownedfilenames/version/hash/size/内容完整和snapshot，目标独立空dir，无任意路径写/符号链接，copy+校验+load FileRepository 重启恢复并与expected验证。UI若提供恢复：明确“恢复到新位置”，用户选择备份文件夹+新空文件夹，单独确认念头条数/旧副本保留再switch；至少开发测试必须做真正 FileRepository load/restart，不能仅导出hash就称备份恢复通过。允许没有restoreUI时提供准确手动恢复步骤，但用户指令“备份实际恢复”必须已测。
- 文件系统访问用可注入adapter或受控io层，单测针对EACCES/ENOSPC/ENOENT/途中复制失败/校验不符/config写失败/目标已有文件/磁盘失连/损坏backup/旧schema backup不overwrite/成功restart。不能全局猴补丁影响他人App。

## 主进程 / UI
- trusted Manage mainframe IPC storageInfo、openStorageDirectory、changeStorage、exportBackup、restore（如提供）。用户按钮触发dialog，准备未保存input（guard包含IME组合拒绝迁移，失败文字保留）；mutationqueue内一刻只一个storageoperation，busy避免重复。prepareViews/leave guard不能在队列中执行。
- 通过原生选择目录对话框让用户确定destination；不擅自移动真实目录。main在fixture测试中mockdialog选择临时目标，生产没有测试特权或新testIPC。
- 设置可scroll/resizable辅助窗顶部clean drag，storagefieldset显示actualpath/open/change/export；忙状态、结果路径、失败明示仍使用原位置。按钮可键盘hoverfocus必要tip，不拥挤。备份没有更改位置、旧copy保留说明贴近动作。
- openPath仅已验证存储dir/backupdir；dialogcancel无变化，storageinfo revision/path可信不是renderer任意shell打开路径。saveSettings保calendarBounds与其他设置。
- startup/exit/currenttestdata清理保证自己测试所有folders/processes；复制backup/restorefixtures aftertests删仅selfcreated dirs，证据screenshots/checksum/report保留。

## 验证
先真实磁盘tmp红绿unit，然后typecheck/build。Electron storage scenario mockdialog/fswritefault verify displayedactualpath、openfolder正确、dirtyinlineinput先flush（含composition未完成拒绝切换）、copy失败oldpath/raw unchanged、migration success/restart读取一致、independentexport currentlocationunchanged、actualrestore/restart ID/content/date/status/order/clips/draft一致、configmissingdir startupfailclosed保持config/backup，退出故障后recover。
兼容 Windows paths、大小写samepath、默认profile和安装升级保全；Windows runner单测+installerpreflight不称真机permission/offline硬件验收。不能降低旧未通过阈值；保存allfailure attempt logs。需要更新README、docs migration/backup/rollback说明：旧preview6读schema3会拒绝，回滚必须使用升级前exactschema2backup在独立位置，不能把仅换旧App当可降级；new softdeletednotes/editedfields未在旧backup时旧版不包含，不能隐藏。

## 阶段 CI 迁移预检补充（同一实现任务）

本任务另拥有 scripts/windows-installed-preflight.cjs。旧脚本以 schema2 fixture 直接 deepEqual 运行时快照，schema3 集成后必失败。保持 schema2 seed 和所有正文、ID、顺序、clip/currentId/position、draft、settings 强断言，显式建立唯一正常迁移的 schema3 预期（createdDay 2026-10-09、creationTimeZone legacy-offset），初始读取和 single-instance 都 deepEqual 完整预期。保存设置后的 ideas 深比较该迁移预期，保存前原主文件字节应仍为 schema2，首次保存后 snapshot.schema2.backup.json 必须与原 seed 字节完全相同且重启不覆盖。旧 exact 内容断言不能删除或改成只查 ok。可抽可测试纯 fixture expected helper，或严格源码比对/Node syntax check；真实运行只在 disposable Windows runner。

installer-preflight.ps1 的 install/reinstall/uninstall SHA 保全逻辑、签名与 PE 图标检查保持，版本仍 .17-preview.1，后续 P6 才统一改 .2。阶段 push 后由 controller 查询真实 CI，不假称本机运行了 Windows 预检。

用户最新强调清理测试垃圾、减电脑负担并避免程序异常退出。每次 fixture finally 先解除故障注入、完成最后保存、正常 close/quit 后等待 PID退出，再 stat 验证删除自有 tmpdir；不能把 app.exit/KILL 当常规通过路径。出现自然退出失败记录失败并保目录，先定位，不伪造 cleanup=true。只跑相关验证，不留空闲测试App；不清依赖/他人进程/旧包/失败证据。收据带真实目录、去重PID、退出和stat结果，父可以复查。
