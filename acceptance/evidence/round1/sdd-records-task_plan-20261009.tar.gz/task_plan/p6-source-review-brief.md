# P6 源码与交付工具任务审查

只读任务Spec/Quality，不改实现或另派reviewer、不commit/push。工作目录 /Users/lihongwei/Desktop/晾念头 : Thoughtline/app；/bin/sh login:false；PATH=/Users/lihongwei/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:/opt/homebrew/bin:/usr/bin:/bin。读取P6 extractedbrief/implementationreport/工作包（含未跟踪新文件）。这是P6源冻结门禁；后续actual包/manifest/发布仍由父根据实际证据验证，不能据此称最终包通过。

具体核验：新.17-preview.2 pkg/lock/两Windows严格version及独立profile路径一致；preview6不可替换。Windows CI source inline/calendar/storage与实际CtrlEnter/Enter/229进程测试接入，只合成data/fakeclipboard/emulatedshortcut，OS/arch/release真实，必留失败logs/screenshots/cleanups。相关测试保完整ID/body/date/order/clip/draft/settings断言；旧package-acceptance转换Detail原地autosave/closeflush/restart/newdraft保全，非跳过。

Mac构建通过builder原生electronDist受控可信参数，strictbuiltApp+DMG签名不放宽，旧系统/签名限制诚实。新launcher在冻结template/generator基础上finaldelivery渲染exactversion/DMG+asarSHA，不接受任意哈希、不fallback安装版、不去隔离，normalopen传独立env、挂载/退出/卸载生命周期和实际PID/stat清理安全。生产/build/testing/CI及docs/delivery Gitmode/object向量与build/source绑定一致且完整，不只是版本。

不重复已跑全量或package阶段的测试，只必要限定验证；有任何发现须Priority/fileline/前置步骤/预期实际/证据，环境未测如实。源码断言和CI不冒物理Windows/IME/DPI/多屏/真实3接收端，Mac材质不冒LiquidGlass。读取user当前指令里的权限/push/privateprerelease已授权，只看此门禁当前范围，未生成包不虚构通过。

输出 .superpowers/sdd/task_plan/p6-source-review.md 两轴及精确发现；父控制修复。审查完成后另有全分支最强独立审查检查P1-P6交界与所有用户11项要求。

额外具体输入边界：source-input-vector需含 vitest.config.ts 与Windows脚本实际读取的 acceptance/evidence/icon-final/resource-verification.json 等构建/验证输入；Git mode/blob canonical向量与raw磁盘SHA分别保留，跨平台行尾不可混作源码差异或错误一致。核命名scope是否覆盖所有实际读取依赖，发现遗漏按影响裁定。已有阶段截图不可被P6重跑覆盖，新增证据需新目录/attempt且旧字节恢复保留。
