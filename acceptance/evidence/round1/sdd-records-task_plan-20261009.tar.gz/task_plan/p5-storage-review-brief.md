# P5 独立审查

工作目录 /Users/lihongwei/Desktop/晾念头 : Thoughtline/app；main。只读审查，不改实现、不提交、不碰真人数据和旧进程。Node24 PATH、/bin/sh login:false、显式 workdir。读取 ../AGENTS.md、p5-storage-brief.md、实施报告 p5-storage-report.md、docs/ROUND1-REPAIR.md、storageLocations.ts、main/bridge/preload/Settings 存储相关 diff、unit/integration 和 Windows installed-preflight diff。用 Spec / Quality 两轴输出 .superpowers/sdd/task_plan/p5-storage-review.md。

优先检查数据安全边界：configured 目录失踪/无权限/坏 config 时 failclosed，不新建空库；默认缓存 profile 和实际 notes path 分开。迁移/导出前所有 dirty/composition guard 和 repository flush，queue 里取最新且不互等。目标同路径/符号链接/非空拒绝，COPYFILE_EXCL、防路径穿越、复制完整/size/hash/validate，prepared new repository 后 config 原子提交再 switch，失败原 repo/config/source 原字节不变，旧副本永保留。清理只自己创建且可核实归属文件。独立 backup 不变位置，manifest 严格、校验后 actual FileRepository restart restore 全字段。

审查故障注入断言 EACCES/ENOSPC/ENOENT/途中失败/hash错误/config失败/断盘/坏backup/目标已有等是否具体保护而非只 r.ok false。UI displayedactualpath/open/change/export 真实有作用、native dialog 仅显式用户触发，失败文字与路径真实，忙态/取消无副作用。恢复若有 UI 单独确认范围且新位置。兼容 Windows paths。Windows installed-preflight 保 schema2 seed→runtime complete schema3 expected，原正文/ID/order/clip/currentId/draft/settings 所有深比较保留，首写 exact legacy raw backup；不在本机假装 Windows runner 已跑。

只跑必要限定测试/受控临时复现。发现精确文件行、优先级、预期/实际、复现步骤和证据，区分源码推导/受控/真机未测。不得为审查重复已通过全工程、长 idle 或启动真人 App。不修代码，父统一处理发现及限定复核。最近删除/日历/保存核心先前审查通过，仅查本任务修改可能破坏集成。
